# Web Technologies — Week 06 English candidate

Candidate 3.0.0-rc.5, pending external acceptance. First extract this outer ZIP, then both inner ZIPs. Do not run files inside an archive viewer. SHA256SUMS covers two inner ZIPs, README and RELEASE metadata. PACKAGE_ID hashes the manifest; the manifest excludes itself, PACKAGE_ID and its method file. The external sidecar identifies the complete outer ZIP.

## C06

Extract `WEBTECH_ASE_C06_EN_GB_RECONSTRUCTED_RC5.zip` into its own folder. Its top-level folder is `WEBTECH_ASE_C06_EN_GB_v1.1.2_RC4`.

- Start: `WEBTECH_ASE_C06_EN_GB_v1.1.2_RC4/index.html`

- Guide: `WEBTECH_ASE_C06_EN_GB_v1.1.2_RC4/course.html`

- Follow the actual package start and guide above; no universal launcher is assumed.

## S06

Extract `WEBTECH_ASE_S06_EN_GB_RECONSTRUCTED_RC5.zip` into its own folder. Its top-level folder is `WEBTECH_ASE_S06_EN_GB_v1.2.2_RC4`.

- Start: `WEBTECH_ASE_S06_EN_GB_v1.2.2_RC4/README.md`

- Guide: `WEBTECH_ASE_S06_EN_GB_v1.2.2_RC4/00_START_HERE/S06_INTERACTIVE_ULTRA_BEGINNER_GUIDE_EN_GB_v1.2.0.html`

- Form: `WEBTECH_ASE_S06_EN_GB_v1.2.2_RC4/05_MOODLE_SUBMISSION/S06_MOODLE_SUBMISSION_FORM_EN_GB_v1.2.0.html`

- Windows integrity check, from the extracted package root: `VERIFY_PACKAGE.cmd`.

- Bash integrity check, from the extracted package root: `./VERIFY_PACKAGE.sh`.

Integrity is not native, browser, Word, Moodle, pilot, AI or institutional acceptance. Complete Day 0 and follow the lecturer's current assessment requirements.
