# Web Technologies — Week 02 English candidate

Candidate 3.0.0-rc.5, pending external acceptance. First extract this outer ZIP, then both inner ZIPs. Do not run files inside an archive viewer. SHA256SUMS covers two inner ZIPs, README and RELEASE metadata. PACKAGE_ID hashes the manifest; the manifest excludes itself, PACKAGE_ID and its method file. The external sidecar identifies the complete outer ZIP.

## C02

Extract `WEBTECH_ASE_C02_EN_GB_RECONSTRUCTED_RC5.zip` into its own folder. Its top-level folder is `WEBTECH_ASE_C02_EN_GB_v1.2.3_RC4`.

- Start: `WEBTECH_ASE_C02_EN_GB_v1.2.3_RC4/00_START_HERE/README_STUDENT.txt`

- Guide: `WEBTECH_ASE_C02_EN_GB_v1.2.3_RC4/01_PRESENTATION/COURSE_02_SEMANTIC_HTML_CSS_RESPONSIVE_UI_AND_ACCESSIBILITY_60_MIN_INTERACTIVE_v1.1_EN_GB.html`

- Windows integrity check, from the extracted package root: `VERIFY_PACKAGE.cmd`.

- Bash integrity check, from the extracted package root: `./VERIFY_PACKAGE.sh`.

## S02

Extract `WEBTECH_ASE_S02_EN_GB_RECONSTRUCTED_RC5.zip` into its own folder. Its top-level folder is `WEBTECH_ASE_S02_EN_GB_v2.3.3_RC5`.

- Start: `WEBTECH_ASE_S02_EN_GB_v2.3.3_RC5/00_START_HERE/README.md`

- Guide: `WEBTECH_ASE_S02_EN_GB_v2.3.3_RC5/00_START_HERE/S02_INTERACTIVE_ULTRA_BEGINNER_GUIDE_EN_GB_v2.3.html`

- Form: `WEBTECH_ASE_S02_EN_GB_v2.3.3_RC5/05_MOODLE_SUBMISSION/FORM_S02_EN_GB.html`

- Windows integrity check, from the extracted package root: `VERIFY_PACKAGE.cmd`.

- Bash integrity check, from the extracted package root: `./VERIFY_PACKAGE.sh`.

Integrity is not native, browser, Word, Moodle, pilot, AI or institutional acceptance. Complete Day 0 and follow the lecturer's current assessment requirements.
