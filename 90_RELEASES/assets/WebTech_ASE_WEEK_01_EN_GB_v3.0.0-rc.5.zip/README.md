# Web Technologies — Week 01 English candidate

Candidate 3.0.0-rc.5, pending external acceptance. First extract this outer ZIP, then both inner ZIPs. Do not run files inside an archive viewer. SHA256SUMS covers two inner ZIPs, README and RELEASE metadata. PACKAGE_ID hashes the manifest; the manifest excludes itself, PACKAGE_ID and its method file. The external sidecar identifies the complete outer ZIP.

## C01

Extract `WEBTECH_ASE_C01_EN_GB_RECONSTRUCTED_RC5.zip` into its own folder. Its top-level folder is `WEBTECH_ASE_C01_EN_GB_v2.0.3_RC4`.

- Start: `WEBTECH_ASE_C01_EN_GB_v2.0.3_RC4/00_START_HERE/README.md`

- Guide: `WEBTECH_ASE_C01_EN_GB_v2.0.3_RC4/01_PRESENTATION/C01_PRESENTATION_EN_GB.html`

- Windows integrity check, from the extracted package root: `VERIFY_PACKAGE.cmd`.

- Bash integrity check, from the extracted package root: `./VERIFY_PACKAGE.sh`.

## S01

Extract `WEBTECH_ASE_S01_EN_GB_RECONSTRUCTED_RC5.zip` into its own folder. Its top-level folder is `WEBTECH_ASE_S01_EN_GB_v6.1.2_RC4`.

- Start: `WEBTECH_ASE_S01_EN_GB_v6.1.2_RC4/00_START_HERE/README.md`

- Guide: `WEBTECH_ASE_S01_EN_GB_v6.1.2_RC4/00_START_HERE/S01_INTERACTIVE_ULTRA_BEGINNER_GUIDE_EN_GB_v6.1.html`

- Form: `WEBTECH_ASE_S01_EN_GB_v6.1.2_RC4/05_MOODLE_SUBMISSION/FORM_S01_EN_GB.html`

- Windows integrity check, from the extracted package root: `VERIFY_PACKAGE.cmd`.

- Bash integrity check, from the extracted package root: `./VERIFY_PACKAGE.sh`.

Integrity is not native, browser, Word, Moodle, pilot, AI or institutional acceptance. Complete Day 0 and follow the lecturer's current assessment requirements.
