# WebTech_ASE — Week 01, EN_GB

Distribution version: 2.1.0-rc.1. Status: release-candidate.

1. Extract this outer weekly ZIP into a new folder.
2. Check the two inner ZIP hashes against `SHA256SUMS.txt`.
3. Extract each inner student ZIP into its own folder. Do not work inside a ZIP preview.
4. Read `00_START_HERE/README_STUDENT.txt` in C02, or `00_START_HERE/README.md` in the other objects, then run `VERIFY_PACKAGE`.
5. Use the course or seminar launcher named below; there is no outer `index.html`.

Course: `OPEN_PRESENTATION.cmd` / `OPEN_PRESENTATION.sh`.
Seminar: `OPEN_BEGINNER_GUIDE.cmd` / `OPEN_BEGINNER_GUIDE.sh`; follow the guide before editing.

Integrity checks establish byte identity. Runtime, browser, native-platform, Word, Moodle and teaching-pilot qualification are separate gates recorded in `RELEASE.json`.
