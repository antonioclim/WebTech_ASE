# Web Technologies — Week 11 English candidate

Candidate 3.0.0-rc.6, pending external acceptance. First extract this outer ZIP, then both inner ZIPs. Do not run files inside an archive viewer. SHA256SUMS covers two inner ZIPs, README and RELEASE metadata. PACKAGE_ID hashes the manifest; the manifest excludes itself, PACKAGE_ID and its method file. The external sidecar identifies the complete outer ZIP.

## C11

Extract `WEBTECH_ASE_C11_EN_GB_RECONSTRUCTED_RC5.zip` into its own folder. This is a flat archive; keep its contents together in that separate folder.

- Start: `index.html`

- Guide: `course.html`

- Follow the actual package start and guide above; no universal launcher is assumed.

## S11

Extract `WEBTECH_ASE_S11_EN_GB_SUCCESSOR_RC6.zip` into its own folder. Its top-level folder is `WEBTECH_ASE_S11_EN_GB_v1.2.4_RC6`.

- Start: `WEBTECH_ASE_S11_EN_GB_v1.2.4_RC6/CLASSROOM_RC6/START.html`

- Guide: `WEBTECH_ASE_S11_EN_GB_v1.2.4_RC6/CLASSROOM_RC6/GUIDE.html`

- Form: `WEBTECH_ASE_S11_EN_GB_v1.2.4_RC6/CLASSROOM_RC6/EVIDENCE_FORM.html`

- Current classroom admission, from the extracted package root: `node CLASSROOM_RC6/verify.mjs initial`. After working on the specified microprojects, run `node CLASSROOM_RC6/verify.mjs work` and record the actual result.

- The original VERIFY_PACKAGE tools and advanced-project checks remain historical material. Their assumptions do not establish admission or completion of the RC6 classroom successor; use its explicit classroom contract and verifier.

Each seminar successor defines two or three bounded, individual classroom microprojects. Complete the stated microproject contract for every project, record the actual observations and submit the specified evidence. Completing a bounded contract does not demonstrate completion of every original full application or every historical test. The complete course still requires separate qualification.

Integrity is not native, browser, Word, Moodle, pilot, AI or institutional acceptance. Complete Day 0 and follow the lecturer's current assessment requirements.
