# Web Technologies — Week 07 English candidate

Candidate 3.0.0-rc.5, pending external acceptance. First extract this outer ZIP, then both inner ZIPs. Do not run files inside an archive viewer. SHA256SUMS covers two inner ZIPs, README and RELEASE metadata. PACKAGE_ID hashes the manifest; the manifest excludes itself, PACKAGE_ID and its method file. The external sidecar identifies the complete outer ZIP.

## C07

Extract `WEBTECH_ASE_C07_EN_GB_RECONSTRUCTED_RC5.zip` into its own folder. Its top-level folder is `WEBTECH_ASE_C07_EN_GB_v1.1.1_RC2`.

- Start: `WEBTECH_ASE_C07_EN_GB_v1.1.1_RC2/index.html`

- Guide: `WEBTECH_ASE_C07_EN_GB_v1.1.1_RC2/course.html`

- Follow the actual package start and guide above; no universal launcher is assumed.

## S07

Extract `WEBTECH_ASE_S07_EN_GB_RECONSTRUCTED_RC5.zip` into its own folder. Its top-level folder is `WEBTECH_ASE_S07_EN_GB_v1.1.2_RC4`.

- Start: `WEBTECH_ASE_S07_EN_GB_v1.1.2_RC4/index.html`

- Guide: `WEBTECH_ASE_S07_EN_GB_v1.1.2_RC4/guide.html`

- Form: `WEBTECH_ASE_S07_EN_GB_v1.1.2_RC4/evidence.html`

- Follow the actual package start and guide above; no universal launcher is assumed.

Integrity is not native, browser, Word, Moodle, pilot, AI or institutional acceptance. Complete Day 0 and follow the lecturer's current assessment requirements.
