# Outer bundle identity

PACKAGE_ID is SHA256 of the exact manifest bytes. The manifest covers exactly README.md, RELEASE.json and two complete inner ZIPs. It excludes SHA256SUMS.txt, PACKAGE_ID.txt and this method file. The sidecar covers the complete container. Hashes are unsigned consistency evidence, not authentication or completed qualification.
