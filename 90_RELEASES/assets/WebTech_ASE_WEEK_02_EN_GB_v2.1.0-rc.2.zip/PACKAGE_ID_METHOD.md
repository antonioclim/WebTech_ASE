# PACKAGE_ID method

`PACKAGE_ID.txt` is the SHA-256 of the exact UTF-8 bytes of `SHA256SUMS.txt`.
