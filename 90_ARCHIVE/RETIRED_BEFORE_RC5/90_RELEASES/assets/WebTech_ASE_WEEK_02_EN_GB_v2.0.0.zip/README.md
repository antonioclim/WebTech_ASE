# WebTech_ASE — Week 02, EN_GB

Extract both student ZIP files before use. Verify `SHA256SUMS.txt` first.
The seminar package contains the individual experiment, Gemini audit and Moodle evidence workflow.
