# Phase 3 FINAL_LOCAL qualification and package identity

Version: 1.2.0. Phase: 3/4. Status: FINAL_LOCAL, qualified by hostile source/data/model audit and actual document-rendering engine checks. This status does not certify React, browser, native Word, launchers, Gemini, Moodle or institutional acceptance. Phase 4 local integration remains separate.

`SOURCE_BINDINGS_v1.2.0.json` binds all immutable current project/preview files and the preserved public v1.1.0 source reference. In package mode every bound byte must match. A future student-work mode permits only the two named assessed target files to differ and does not certify their behaviour. Optional P02 is separate practice and is not a marking obligation.

In future student-work mode, a changed teaching preview target is accepted separately only when it is an exact one-way byte copy of its corresponding current assessed target. This does not add an assessed editable path: P01 App.jsx and P03 SearchPanel.jsx remain the only assessed targets. Preview helpers, entries, tests, styles and lockfiles remain exact. Package mode still requires all distributed preview bytes to match the original starter.

Package identity method: enumerate regular files under the package root, excluding only `MANIFEST.json` and `PACKAGE_ID.txt`; sort POSIX relative paths; each identity line is `sha256 + two spaces + relative_path + LF`; hash the UTF-8 concatenation with SHA-256. The manifest records byte length and SHA-256 for each payload. The two identity metadata files are non-payload metadata and are counted separately. ZIP whole-file SHA-256 and CRC are transport/data checks, not execution or authorship authentication.

No canonical app, helper or test was executed. Node/npm, browser, native Word/OS, actual Gemini and live Moodle acceptance remain open. HTML UI branches and screenshots are not claimed observed. Document rendering verifies the produced document layout in the rendering engine only. Runtime-owned rendering tools are distinct from project runtime execution.

Declared generated-directory policy: exact-package mode rejects unbound additions, including generated directories. Future `--student-work` mode excludes only `.vite`, `dist` and `node_modules` directory segments below the active project/optional/teaching roots, reporting them as unqualified exclusions. No exclusion applies inside `source_reference/v1.1.0` or to a registry-bound file. Other added source files, unsafe portable names, symlinks and malformed registry rows fail.
