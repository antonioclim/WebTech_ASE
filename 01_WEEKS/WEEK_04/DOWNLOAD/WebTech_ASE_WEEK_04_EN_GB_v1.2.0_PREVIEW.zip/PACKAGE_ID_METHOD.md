# Wrapper identity

SHA256SUMS.txt lists every regular payload except itself and PACKAGE_ID.txt, sorted by path with LF endings. PACKAGE_ID.txt contains SHA-256 of those exact manifest bytes. The ZIP sidecar hashes the whole ZIP. ZIP rebuilding is deterministic for the same payload, not a claim of runtime qualification.
