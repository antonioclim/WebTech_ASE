# S04 active fields and evidence guide

P01 Multi-source Dashboard central; P02 Task List required later; P03 Resilient Fetch optional.

The compact form initially shows the class/core fields. Open the later/final view for all required independent work, final evidence and declarations. Optional work stays optional. Hiding a field does not remove it, change its import ID or excuse an unmet required gate. Print review includes the complete record.

## Record each witness once

Use a stable evidence ID for each case and retain: prediction before action; exact action or source; expected result; observed result; mechanism; limitation; locator. Keep actual excerpts in one place. Summary fields cite the evidence ID and add the particular comparison or decision they ask for, rather than repeat the same transcript.

Identity is one record. Fixed seminar/version labels are metadata, not observations. Package ID, real date, environment and access are never inferred from a required version. Baseline, objective and regression outcomes remain distinct; source/model/actual classes remain explicit.

## Active entry groups

Use the named identity, prediction/action, mechanism, AI critique, required portfolio, reflection and personal review groups in the form. P03 in S03 and P02 in S04 remain required later work; do not treat the compact class view as final completion.

## Finish and review

Preserve a wrong original prediction. Give a reason and next check for UNKNOWN/BLOCKED work. A schema-complete form or imported JSON does not re-execute a test, authenticate an AI exchange or confirm submission. Renew personal declarations after material edits/imports. Personally inspect the actual saved private PDF and the real Assignment status.

Required P02 is later work. One core P01 controller is bounded, but full observations and AI review still compete for the hour.

All timing ranges remain planning estimates unless an actual classroom pilot measured them. New recovery or institutional grading treatment needs the authorised owner; this guide does not adopt such a policy.
