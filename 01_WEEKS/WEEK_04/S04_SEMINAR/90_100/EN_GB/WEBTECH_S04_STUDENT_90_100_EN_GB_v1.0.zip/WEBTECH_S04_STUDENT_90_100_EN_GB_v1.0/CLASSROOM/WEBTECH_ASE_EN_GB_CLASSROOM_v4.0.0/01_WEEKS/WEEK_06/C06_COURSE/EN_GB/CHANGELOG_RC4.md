# Local RC4 derivative

Original carrier `01_WEEKS/WEEK_06/C06_COURSE/EN_GB/DOWNLOAD/WEBTECH_ASE_C06_EN_GB_v1.1.1_RC2.zip` remains preserved byte for byte.

This carrier contains reviewed local changes and refreshed authentic package control descriptors.
The detailed path, hash, mode and provenance record is `DERIVED_CARRIER.json`.
Package identity authenticates this carrier; it does not prove runtime or native acceptance.
Native and owner acceptance remain pending.
