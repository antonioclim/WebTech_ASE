# S05: complete bounded classroom microprojects (RC6)

Each student completes all 3 projects individually in the classroom session. These are newly bounded projects, separate from the full historical application contracts. Setup is completed before the session; the allocation is a design estimate requiring a novice pilot, not measured completion evidence. Read the original guide only as historical context for its separate full-application contract.

## P01 — Closed task-body boundary

Complete scope: Accept exactly own title(nonblank trimmed string) and completed(boolean); return fresh representation, reject other fields/types before service call.

Edit only `CLASSROOM_RC6/targets/p01.mjs` from the package root. Commands:

```text
node CLASSROOM_RC6/kit.mjs check P01
node CLASSROOM_RC6/kit.mjs observe P01
```

Record: Valid returned body; String false and unknown-key rejection; Input preservation. Record actual results, including failures or blockers; no result is prefilled.

## P02 — Exactly-once terminal logger

Complete scope: Build a terminal callback that records request identity/status/elapsed time once even when supplied finish and close events both fire.

Edit only `CLASSROOM_RC6/targets/p02.mjs` from the package root. Commands:

```text
node CLASSROOM_RC6/kit.mjs check P02
node CLASSROOM_RC6/kit.mjs observe P02
```

Record: Callback event order; One log after two callbacks; Monotonic-clock duration and limitation. Record actual results, including failures or blockers; no result is prefilled.

## P03 — Public outcome mapping

Complete scope: Map created/notfound/conflict to201+Location/404/409 with safe envelopes, never expose an internal error message.

Edit only `CLASSROOM_RC6/targets/p03.mjs` from the package root. Commands:

```text
node CLASSROOM_RC6/kit.mjs check P03
node CLASSROOM_RC6/kit.mjs observe P03
```

Record: Real loopback create response/status/header; Conflict and internal safe responses; Claim-vs-observation explanation. Record actual results, including failures or blockers; no result is prefilled.

## Initial and complete checks

```text
node CLASSROOM_RC6/kit.mjs initial
node CLASSROOM_RC6/kit.mjs check all
```

Initial checks require the untouched targets and exact declared assertion-failure names. A process timeout, exception, damaged source boundary or missing native module is a genuine fault. Keep every private fixture, JSON draft, log and PDF outside the entire extracted collection. Use your home-folder `WebTech_Evidence/S05`: `%USERPROFILE%\WebTech_Evidence\S05` on Windows or `$HOME/WebTech_Evidence/S05` on macOS/Linux. Keep the extracted collection in a different folder. The [detailed tutorial](../../TUTORIAL.html) provides the quoted absolute paths and operating-system commands. Checkers create only owned ephemeral resources. Use capability preflight; ENV_OK/ENV_WARN permit the checked operation and ENV_BLOCKED names the missing capability; npm installs are unnecessary for this route.

For genuine browser/HTTP work, run `node CLASSROOM_RC6/kit.mjs serve` in a separate terminal, use only its printed READY origin and keep it running. Stop it with Ctrl+C once in that terminal and read STOPPED_OWNED_LISTENER. A stale origin or unknown cleanup remains a blocker.

## Current unpiloted plan: 120–165 minutes

Complete all 3 microprojects individually. Plan 30–45 minutes for each required project. Prepare the actual runtime capabilities before class. The following durations are planning estimates, not measured completion times, empirical minimums or completion guarantees.

| Planned duration | Individual activity |
| --- | --- |
| 5 minutes | Prepared environment and privacy check |
| 30–45 minutes | P01 — required bounded project with progress and evidence checkpoints |
| 30–45 minutes | P02 — required bounded project with progress and evidence checkpoints |
| 30–45 minutes | P03 — required bounded project with progress and evidence checkpoints |
| 15 minutes | One shared genuine bounded AI critique and independent check |
| 5 minutes | Review the evidence and save one individual PDF |
| 5 minutes | Final recap: achievement, learning, reason and next transfer |

For each project, use about 5 planned minutes to read the contract and record a prediction, 20–30 to implement, run checks and investigate results, then 5–10 to review a counterexample and record evidence. These checkpoints total 30–45 planned minutes.

If the actual institutional slot is shorter, agree a taught continuation with the lecturer before the session. All projects remain required individual classroom work; keep unfinished work marked unfinished. The end of a meeting does not establish completion.

The current `GUIDE.html` and the separate top-level `project_schedule` in `CLASSROOM_SCOPE.json` govern these planned blocks. The `projects` array retains the unchanged assessment contract.

## One actual AI claim

S05 classroom claim audit. Review only one claim about the bounded project; do not provide a completed assessed implementation or modify tests.
My preserved prediction: [one specific claim]
Synthetic fixture and relevant contract: [small input plus rule]
My actual observation: [output/error or NOT EXECUTED]
State whether the claim is observed, inferred or unknown. Propose one minimum independent counterexample. Explain one limitation. I will run the witness myself and record ACCEPTED, REJECTED, PARTLY ACCEPTED or UNKNOWN. Model text is not test evidence. Do not invent execution.

Keep a compact experiment record for each project: prediction (before running), action/input/target, actual result with evidence excerpt, comparison/mechanism and limitation. Add one specific final reflection and one independently verified AI claim. No credentials, real personal data, private Moodle records or whole AI conversations. Use the current stage-based formative assessment and save one `TW2026_S05_GROUP_Surname_Firstname.pdf`. Missing personal execution or AI access remains explicitly unresolved. The form checks completeness, not truth, grades or Moodle receipt.

## Scope limit

The callback witness is a bounded event contract, not Express middleware qualification. Actual HTTP uses a supplied Node adapter, and classroom mapping does not complete the historical full Express projects.

## Final recap before submission

Explain how your closed request-body boundary, exactly-once terminal logger and public outcome mapping changed an actual result. State why the negative case matters, distinguish the supplied adapter from full Express qualification and name the next boundary to check.

Finish the recap before actual submission. If it changes your form record, update the form, renew the affected declarations and export and review the latest single PDF before uploading it. Use the agreed continuation if review remains unfinished; do not submit an earlier PDF as the updated record.

## Current carrier and historical references

The `CLASSROOM_RC6` folder, retained edition labels and v1 record values identify the existing teaching carrier and record contract. Use the current candidate unit identity shown by the collection entry for a new record. Linked original guides and forms are read-only historical references; their omitted full-application starters and tests are not the current assignment.

[Current formative assessment](../FORMATIVE_ASSESSMENT.html) · [Full twelve-stage tutorial](../../TUTORIAL.html)
