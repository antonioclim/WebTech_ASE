# Verify this Windows-profile teaching distribution

The complete distribution contains 14 courses, 14 seminars, two setup units and their runnable support. Its 40 required individual projects and 38 unfinished learner targets retain their supplied contracts. The declared publication profile is `windows-observed-v4.0.0`; see [the exact profile](../metadata/PUBLICATION_PROFILE.json) and [qualification scope](../00_START_HERE/QUALIFICATION.html).

From the extracted collection root run:

```text
node 00_TOOLS/qa/VERIFY_COLLECTION.mjs
```

After changing only the declared learner targets or creating declared runtime directories run:

```text
node 00_TOOLS/qa/VERIFY_COLLECTION.mjs --allow-student-edits
```

Python provides an optional independent check:

```text
python 00_TOOLS/qa/validate_public_repo.py --strict
```

These checks verify supplied bytes and project identities. They neither grade an implementation nor execute a browser. Follow each selected seminar's commands from its stated working directory. [Runtime support](runtime/README.md) describes the operation-selected policy.

General qualification remains **NOT_FINAL** and broad native acceptance remains false. Source technical eligibility applies only to the declared observed Windows profile with its recorded limits. The packaging tool does not repeat the owner browser/PDF batch or execute native macOS. Retained macOS/Linux guidance and historical Word references do not extend the accepted profile. Keep private drafts, logs, screenshots and PDFs outside the complete extracted collection.

Owner publishing, maintenance, acceptance and automation files are omitted. [The derivation record](../metadata/DISTRIBUTION_DERIVATION.json) binds the exact authenticated source commit, source identity and filtering. All teaching unit bytes and unit identities are retained. Preparing this archive performs no publication and changes no frozen release.
