# S01: complete bounded classroom microprojects (RC6)

Each student completes all 2 projects individually in the classroom session. These are newly bounded projects, separate from the full historical application contracts. Setup is completed before the session; the allocation is a design estimate requiring a novice pilot, not measured completion evidence. Read the original guide only as historical context for its separate full-application contract.

## P01 — HTTP exchange classifier

Complete scope: Classify the three real loopback exchanges as CSS GET, query GET and JSON POST, preserving method/path/status/media boundaries.

Edit only `CLASSROOM_RC6/targets/p01.mjs` from the package root. Commands:

```text
node CLASSROOM_RC6/kit.mjs check P01
node CLASSROOM_RC6/kit.mjs observe P01
```

Record: Preserved three-row prediction; Actual origin, request/response records; Classifier output and one header-vs-body explanation. Record actual results, including failures or blockers; no result is prefilled.

## P02 — Precise greeting resource

Complete scope: Implement exact GET greeting path recognition, percent decoding, trimming, blank/extra-segment rejection and a stable JSON envelope.

Edit only `CLASSROOM_RC6/targets/p02.mjs` from the package root. Commands:

```text
node CLASSROOM_RC6/kit.mjs check P02
node CLASSROOM_RC6/kit.mjs observe P02
```

Record: Encoded name response; Blank and extra-segment responses; Check log and unsupported-method limit. Record actual results, including failures or blockers; no result is prefilled.

## Initial and complete checks

```text
node CLASSROOM_RC6/kit.mjs initial
node CLASSROOM_RC6/kit.mjs check all
```

Initial checks require the untouched targets and exact declared assertion-failure names. A process timeout, exception, damaged source boundary or missing native module is a genuine fault. Keep every private fixture, JSON draft, log and PDF outside the entire extracted collection. Use your home-folder `WebTech_Evidence/S01`: `%USERPROFILE%\WebTech_Evidence\S01` on Windows or `$HOME/WebTech_Evidence/S01` on macOS/Linux. Keep the extracted collection in a different folder. The [detailed tutorial](../../TUTORIAL.html) provides the quoted absolute paths and operating-system commands. Checkers create only owned ephemeral resources. Reference Node is v24.21.0; npm installs are unnecessary for this route.

For genuine browser/HTTP work, run `node CLASSROOM_RC6/kit.mjs serve` in a separate terminal, use only its printed READY origin and keep it running. Stop it with Ctrl+C once in that terminal and read STOPPED_OWNED_LISTENER. A stale origin or unknown cleanup remains a blocker.

## Current unpiloted plan: 90–120 minutes

Complete all 2 microprojects individually. Plan 30–45 minutes for each required project. Prepare the prescribed runtime and expressly required dependencies before class. The following durations are planning estimates, not measured completion times, empirical minimums or completion guarantees.

| Planned duration | Individual activity |
| --- | --- |
| 5 minutes | Prepared environment and privacy check |
| 30–45 minutes | P01 — required bounded project with progress and evidence checkpoints |
| 30–45 minutes | P02 — required bounded project with progress and evidence checkpoints |
| 15 minutes | One shared genuine bounded AI critique and independent check |
| 5 minutes | Review the evidence and save one individual PDF |
| 5 minutes | Final recap: achievement, learning, reason and next transfer |

For each project, use about 5 planned minutes to read the contract and record a prediction, 20–30 to implement, run checks and investigate results, then 5–10 to review a counterexample and record evidence. These checkpoints total 30–45 planned minutes.

If the actual institutional slot is shorter, agree a taught continuation with the lecturer before the session. All projects remain required individual classroom work; keep unfinished work marked unfinished. The end of a meeting does not establish completion.

The current `GUIDE.html` and the separate top-level `project_schedule` in `CLASSROOM_SCOPE.json` govern these planned blocks. The `projects` array retains the unchanged assessment contract.

## One actual AI claim

S01 classroom claim audit. Review only one claim about the bounded project; do not provide a completed assessed implementation or modify tests.
My preserved prediction: [one specific claim]
Synthetic fixture and relevant contract: [small input plus rule]
My actual observation: [output/error or NOT EXECUTED]
State whether the claim is observed, inferred or unknown. Propose one minimum independent counterexample. Explain one limitation. I will run the witness myself and record ACCEPTED, REJECTED, PARTLY ACCEPTED or UNKNOWN. Model text is not test evidence. Do not invent execution.

Keep a compact experiment record for each project: prediction (before running), action/input/target, actual result with evidence excerpt, comparison/mechanism and limitation. Add one specific final reflection and one independently verified AI claim. No credentials, real personal data, private Moodle records or whole AI conversations. Use the current classroom evidence form and save one `TW2026_S01_GROUP_Surname_Firstname.pdf`. Missing personal execution or AI access remains explicitly unresolved. The form checks completeness, not truth, grades or Moodle receipt.

## Scope limit

This new bounded classroom implementation is separate from the historical original full projects. Loopback HTTP does not qualify a native browser, another OS or every HTTP input.

## Final recap before submission

Explain which HTTP request and response boundaries you can now distinguish, why pathname and query are different and what your greeting resource actually accepted or rejected. Name the observation that supports each statement, one untested input and your next check.

Finish the recap before actual submission. If it changes your form record, update the form, renew the affected declarations and export and review the latest single PDF before uploading it. Use the agreed continuation if review remains unfinished; do not submit an earlier PDF as the updated record.

## Current carrier and historical references

The `CLASSROOM_RC6` folder, retained edition labels and v1 record values identify the existing teaching carrier and record contract. Use the current candidate unit identity shown by the collection entry for a new record. Linked original guides and forms are read-only historical references; their omitted full-application starters and tests are not the current assignment.
