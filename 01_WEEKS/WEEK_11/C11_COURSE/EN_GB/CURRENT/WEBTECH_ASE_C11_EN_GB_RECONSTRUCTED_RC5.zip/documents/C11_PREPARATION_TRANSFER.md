# C11 — Preparation and Transfer

## Before the course: read, predict, distinguish

Read the package index, SOURCE_NOTES.md and the opening handout sections. This phase requires no installation, external account, password, session cookie or server. Inspect the five canonical example directories as source files; their historical run instructions are not an instruction to start them now.

Write a short prediction for each of these distinctions: TLS versus principal verification; principal verification versus a specific permission; server expiry versus a cookie lifetime; response sharing versus request intent; bound data versus SQL execution. Name the boundary rather than a library alone. Use fictional labels instead of copying private requests.

## During the 60-minute course

Follow the eight intervals in course.html. At each intermezzo, make the prediction before revealing the explanatory model. The model accepts only a selected fixed scenario and a text prediction. Its output is explicitly synthetic and cannot be substituted for an observed Express or browser result.

For one example, record the source file, function or route, the property it actually implements and one stronger claim it cannot support. A useful choice is the distinction between EX-03’s cookie header and P01’s server-owned expiry. Do not paste the cookie’s value; an attribute checklist is enough.

## A bounded Gemini critique for later seminar use

After the relevant individual work, select one own claim and a minimal sanitised excerpt. The reusable prompt in GEMINI_PROMPT.txt asks for a critique, not the complete policy or two-helper repair. Keep the relevant actual prompt and response extract only. Then compare the claim with the exact source contract or an independent protective check.

Record one of ACCEPTED, REJECTED, PARTIALLY ACCEPTED or UNKNOWN. Explain the supporting observation, any correction and the remaining limit. A synthetic claim included in the course is not a conversation received from Gemini. An unavailable exchange remains pending; a separately authorised alternative cannot be granted by a form selector.

## Transfer obligations

P02 remains the full central task in authorization-policy.js. P01 is capstone integration. The mandatory P03 portfolio is the separately identified two-class 11.3A route, CORS and CSRF. It uses static source-to-boundary analysis and benign protective verification, not exploit execution. Do not complete or launch the historical all-five starter as an implicit requirement.

The eventual S11 record combines individual P02 evidence, the reduced portfolio and critique in one PDF. The 48-field form and the S11 starter package belong to the next phase and are not included here. The teacher sets the eventual deadline; no date or separate C11 Assignment is created now.

## End-of-course self-check

For your chosen boundary, write: owner; trusted fact; untrusted input category; expected allowance; expected refusal; evidence class; one limit. Leave unknown results visibly unknown. A hash proves identity of bytes, not correct behaviour. Header assertions do not prove browser enforcement; helper results do not prove middleware order. STOP at 60, preserving outstanding work for the later deadline.
