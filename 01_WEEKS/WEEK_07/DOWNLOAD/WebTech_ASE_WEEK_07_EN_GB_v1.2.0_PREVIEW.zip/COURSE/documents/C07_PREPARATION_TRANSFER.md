# C07 · Preparation and transfer

## Before the meeting

Read the first three handout sections and inspect the declarations in canonical/01-relationship-shapes/example.js. Do not install or run dependencies as part of this reading route. The presentation, handout and laboratory open directly from local files. Genuine examples require the separately prepared project-local stack; see guide.html.

Write three brief predictions: where ticketType belongs, which constraint prevents duplicate membership and what the lazy statement count would be for three parents. Label these SOURCE_REASONING. An archived assertion is not your executed result.

Recall Week 06’s distinction between metadata, actual ORM state and client observations. C07 adds the consistency boundary across related records. The new laboratory is a JavaScript teaching model, not a database. Opening it does not load Sequelize or a native driver.

Use the course home index.html. For the presentation select course.html; use Previous, Next or the screen selector. Arrow keys work outside interactive controls. Text size has a 40–160% range independent of browser zoom. Reading mode exposes the whole sequence and print styles include explanations. Neither a print request nor a browser download request proves that a file was saved.

Read SOURCE_NOTES.md before interpreting Example01, Example03 or Example04 README claims. Their discrepancies are preserved and explained. In particular, Example04’s cursor predicate does not follow every permitted primary ordering. The new catalogue trace is separately identified; it does not rewrite the original endpoint.

Bring no real personal dataset or credentials into the experiment. A tiny sanitised fixture makes predictions and counterexamples easier to inspect. No application installation is hidden in the 60-minute teaching plan.

## During the 60-minute core

Follow the same evidence loop at each checkpoint: predict, inspect or execute, compare and state a limit. Enter laboratory predictions before running the model. Export notes explicitly as JSON before leaving the page; there is no automatic persistent storage. Reimported notes are marked unverified and are not replayed tests.

| Minutes | Work and retained observation |
|---|---|
| 00–06 | State the booking invariant and choose an evidence class |
| 06–16 | Locate keys, membership facts and constraint ownership |
| 16–24 | Distinguish statement count, row multiplication and representation |
| 24–32 | Compare resource identities and repeated intended effects |
| 32–38 | Trace the fixed numeric catalogue’s cursor counterexample |
| 38–52 | Inventory all five database operations and outer settlement |
| 52–58 | Separate failure sites, recovery, races and one generated claim |
| 58–60 | State a mechanism, a witness and a limitation; stop |

The course source plans 96 minutes. This is an explicit 60-minute selection with deeper reading, not a claim that every original segment retained its original duration. The reserved 30 minutes of the booking are not an overflow buffer.

The laboratory reports model outputs only. The exact examples’ database assertions need the real project dependencies and native driver. If the environment is unavailable, keep the distinction instead of attaching the laboratory result to an ORM claim. You can still complete the conceptual reading and record the next discriminating experiment.

At the stop, identify projects/p02/src/book-seats.js as the seminar edit target. No C07 handout upload is required. The S07 form and complete seminar package follow in the next production phase.

## After the meeting: transfer and ADR preparation

Finish any handout sections not discussed in depth. Run the fixed-snapshot catalogue model again with its duplicate-rank case and explain why the tuple rule differs from id > lastId. Do not infer a guarantee under concurrent key updates. Examine the exact source discrepancy notes rather than claiming all historical assertions have been executed.

Prepare the required ADR questions: what client operation is addressed, what identifies its resource, which related state belongs in one transaction, what is the intended effect of repetition and what alternative did you reject? Use the semester project when defined. Otherwise make the provisional course-domain choice explicit and state when to revisit it. Do not copy a generic “REST is better” conclusion.

The proposed ADR length is 300–500 words plus a compact client-effect table. This is a teaching scope rather than an original canonical word limit. The full P03 Registration API Redesign implementation is not separately compulsory. P01 is optional advanced work. P02 Transactional Booking remains the only required complete implementation in S07.

The P02 source estimates 55–65 minutes for the implementation alone. The seminar allocates 28 minutes inside its core and makes remaining work explicit. Finish outstanding work on the same project and the brief ADR before the later teacher-configured deadline. Do not fabricate a completed test or a live Gemini exchange to close the form at minute 60.

For a bounded Gemini review, use GEMINI_PROMPT.txt. The offline SYNTHETIC_CLAIM.txt is clearly labelled practice, not an actual conversation. Keep one claim, one check, a justified verdict, correction and limitation. No whole-conversation upload is requested.

The final assessment is one TW2026_S07_GROUP_Surname_GivenName.pdf. This course package does not generate or submit that form. Follow the later S07 guide. canonical/reading-list-next.md gives the original next-reading route towards React with Vite. Do not install the next week’s stack during this meeting.