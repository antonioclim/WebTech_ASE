/* Newly authored inert schema; no executable project data. */
globalThis.S07_SCHEMA = {
  "schema": "TW2026-S07-EVIDENCE",
  "version": "1.2.1",
  "maxImportBytes": 2000000,
  "sections": [
    {
      "id": "identity",
      "title": "Identity and observed environment",
      "intro": "Record measured versions and the actual dependency state. Missing prerequisites are not failed objectives.",
      "fields": [
        {
          "id": "surname",
          "label": "Surname",
          "kind": "input",
          "max": 128,
          "phase": "core",
          "default": "",
          "help": "Your surname for the private assessment submission. Do not publish this completed form."
        },
        {
          "id": "given",
          "label": "First name",
          "kind": "input",
          "max": 128,
          "phase": "core",
          "default": "",
          "help": "Your first name for the private assessment. Check the filename before saving."
        },
        {
          "id": "group",
          "label": "Group",
          "kind": "input",
          "max": 128,
          "phase": "core",
          "default": "",
          "help": "Your actual seminar group."
        },
        {
          "id": "kits",
          "label": "Kit version",
          "kind": "input",
          "max": 128,
          "phase": "core",
          "default": "",
          "help": "Record the S07 kit version actually used. Review imported C07/S07 strings; do not infer a package ID from them."
        },
        {
          "id": "os",
          "label": "Operating system",
          "kind": "input",
          "max": 128,
          "phase": "core",
          "default": "",
          "help": "Name the operating system and version actually used."
        },
        {
          "id": "terminal",
          "label": "Terminal and client used",
          "kind": "input",
          "max": 128,
          "phase": "core",
          "default": "",
          "help": "Name the terminal and HTTP client. Browser screenshots are optional; it is not a substitute for a reproducible command."
        },
        {
          "id": "node",
          "label": "Observed Node version",
          "kind": "input",
          "max": 128,
          "phase": "core",
          "default": "",
          "help": "Copy node --version or UNKNOWN: reason. The reference v24.21.0 is not a measurement."
        },
        {
          "id": "npm",
          "label": "Observed npm version",
          "kind": "input",
          "max": 128,
          "phase": "core",
          "default": "",
          "help": "Copy npm --version or UNKNOWN: reason. The reference 11.19.0 is not a measurement."
        },
        {
          "id": "dependencies",
          "label": "Actual project dependency and native-driver state",
          "kind": "textarea",
          "max": 12000,
          "phase": "core",
          "default": "",
          "help": "Record preflight output and distinguish version resolution from loading sqlite3 and actually running Sequelize. Cite the original log."
        },
        {
          "id": "date",
          "label": "Date of individual work",
          "kind": "input",
          "max": 128,
          "phase": "core",
          "default": "",
          "help": "Enter the actual date and time zone of your work. Record the separate Gemini interaction date in its context field."
        },
        {
          "id": "seminar_id",
          "label": "Seminar identity: S07",
          "kind": "input",
          "max": 128,
          "phase": "core",
          "default": "S07",
          "help": "S07 is the fixed identity of this worksheet. It is not a measured environment observation."
        },
        {
          "id": "package_id",
          "label": "Actual S07 PACKAGE_ID",
          "kind": "input",
          "max": 128,
          "phase": "core",
          "default": "",
          "help": "Copy the 64-character S07 PACKAGE_ID.txt value from the unedited kit. Do not guess it or substitute a C07 ID. If unavailable record UNKNOWN: reason."
        },
        {
          "id": "browser",
          "label": "Observed browser and version",
          "kind": "input",
          "max": 128,
          "phase": "core",
          "default": "",
          "help": "Record the browser and version actually used or UNKNOWN: reason. Do not copy a reference version as a measurement."
        }
      ]
    },
    {
      "id": "prediction",
      "title": "Prediction and starting state",
      "intro": "Keep the original prediction. Use a fresh named fixture and separate the unsafe comparison from your implementation.",
      "fields": [
        {
          "id": "input_fixture",
          "label": "Exact fixture and booking input",
          "kind": "textarea",
          "max": 12000,
          "phase": "core",
          "default": "",
          "help": "Identify the fresh P02 seed, event, attendee and seats. Use returned IDs rather than guessing later generated IDs."
        },
        {
          "id": "prediction",
          "label": "Prediction recorded before execution",
          "kind": "textarea",
          "max": 12000,
          "phase": "core",
          "default": "",
          "help": "Before execution predict availability, booking count and audit count for success and for a controlled failure. Never replace this prediction retrospectively."
        },
        {
          "id": "invariant",
          "label": "Booking invariant and its scope",
          "kind": "textarea",
          "max": 12000,
          "phase": "core",
          "default": "",
          "help": "Name the facts which must agree and scope the invariant to the supplied fixture and operations. State what concurrency or crash behaviour is not covered."
        },
        {
          "id": "edit_path",
          "label": "Allowed edit and diff summary",
          "kind": "textarea",
          "max": 12000,
          "phase": "core",
          "default": "",
          "help": "Change only 02_PROJECTS/p02/src/book-seats.js. Record the diff. Models, tests, dependencies and locks are protected."
        },
        {
          "id": "initial_checks",
          "label": "Initial baseline/objective/regression status",
          "kind": "textarea",
          "max": 12000,
          "phase": "core",
          "default": "",
          "help": "Copy the baseline/objective/regression results or the exact prerequisite block. A TypeError, timeout or native-load error is not an intended assertion failure."
        },
        {
          "id": "before_state",
          "label": "Initial inventory, bookings and audits",
          "kind": "textarea",
          "max": 12000,
          "phase": "core",
          "default": "",
          "help": "Record the state before the call and name the command or witness. Source expectations must not be labelled as measured rows."
        },
        {
          "id": "unsafe_observation",
          "label": "Supplied unsafe comparison: actual result or pending",
          "kind": "textarea",
          "max": 12000,
          "phase": "core",
          "default": "",
          "help": "Use the supplied unsafe comparator in a fresh fixture when possible. Record its actual partial state or PENDING with the reason."
        },
        {
          "id": "unsafe_limit",
          "label": "What the comparison does not establish",
          "kind": "textarea",
          "max": 12000,
          "phase": "core",
          "default": "",
          "help": "Explain why this sequential counterexample is not a concurrency test or a qualified production design."
        },
        {
          "id": "prediction_two",
          "label": "Second prediction before the failure experiment",
          "kind": "textarea",
          "max": 12000,
          "phase": "core",
          "default": "",
          "help": "Before observing the separate controlled failure, record your second prediction with time/order and named fixture. Keep the first prediction unchanged. If you already observed the outcome say LATE: reason; do not invent prior timing."
        },
        {
          "id": "expected_result",
          "label": "Expected result before execution",
          "kind": "textarea",
          "max": 12000,
          "phase": "core",
          "default": "",
          "help": "Label this SOURCE_EXPECTATION. Record expected availability, Booking count and BookingAudit count before execution. Keep this separate from measured rows."
        }
      ]
    },
    {
      "id": "transaction",
      "title": "Implementation and failure evidence",
      "intro": "Record the command, evidence class and actual result. A module model is not SQL rollback.",
      "fields": [
        {
          "id": "operation_sequence",
          "label": "Observed sequence and awaited operations",
          "kind": "textarea",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "Record event lookup, duplicate lookup, event save, booking creation, callback and audit creation in their observed order. Name the trace and its class."
        },
        {
          "id": "transaction_witness",
          "label": "Same transaction identity at all five database operations",
          "kind": "textarea",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "Name all five database operations: Event.findByPk, Booking.findOne, event.save, Booking.create and BookingAudit.create. Record one shared non-null transaction identity plus the awaited callback. A source or module model trace does not prove native SQL rollback."
        },
        {
          "id": "success_state",
          "label": "Committed success state and returned values",
          "kind": "textarea",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "Give availability and actual booking/audit rows after success, plus the detached result. Distinguish the model from genuine ORM execution."
        },
        {
          "id": "success_http",
          "label": "HTTP status, Location and body or pending",
          "kind": "textarea",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "Record the actual POST status, Location and response body with its client command. The supplied application has no GET /api/bookings/:id route; do not invent one."
        },
        {
          "id": "callback_failure",
          "label": "Controlled callback failure: input and actual error",
          "kind": "textarea",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "Identify the controlled afterBookingCreated rejection, its origin and observed error. Label any injection."
        },
        {
          "id": "audit_failure",
          "label": "Controlled audit-create rejection: input and actual error",
          "kind": "textarea",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "Identify the separately injected BookingAudit.create rejection. This differs from throwing before the call."
        },
        {
          "id": "rollback_state",
          "label": "State before and after each failed attempt",
          "kind": "textarea",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "For each failed attempt record before and after availability, bookings and audits. A passing substitute is not physical rollback."
        },
        {
          "id": "error_identity",
          "label": "Known outcomes and unexpected error identity",
          "kind": "textarea",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "Record preserved unexpected-error identity and known error codes. UniqueConstraintError alone does not identify the failing operation."
        },
        {
          "id": "commit_boundary",
          "label": "Callback completion versus outer transaction settlement",
          "kind": "textarea",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "Separate callback completion from the returned transaction promise settling and the caller receiving a result. Label any delayed model gate as a model."
        },
        {
          "id": "recovery",
          "label": "Successful independent booking after a failed attempt",
          "kind": "textarea",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "After a controlled failed booking, record an independent successful booking on the same database instance and check all three state components."
        }
      ]
    },
    {
      "id": "limits",
      "title": "Evidence classes and interpretation",
      "intro": "Name the scope of each observation and the checks that remain outstanding.",
      "fields": [
        {
          "id": "invalid_outcomes",
          "label": "Invalid, missing, sold-out and duplicate cases",
          "kind": "textarea",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "Record invalid seats, missing event, sold-out and duplicate outcomes with unchanged state. Source order checks sold-out before duplicate; do not reverse it."
        },
        {
          "id": "fixture_identity",
          "label": "Environment and fixture identity of each witness",
          "kind": "textarea",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "Map each witness to its fixture, command and measured runtime. Use GENUINE_ORM_SQLITE for genuine ORM/SQLite, LOCAL_HTTP for the actual local HTTP client, MODULE_MODEL for substitutes and SOURCE_REASONING for source reading. Imported labels remain unverified."
        },
        {
          "id": "actual_stack_state",
          "label": "Actual ORM/HTTP evidence state",
          "kind": "select",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "ACTUAL_RECORDED declares genuine ORM/SQLite and local HTTP observations. The checker cannot authenticate them. A separate alternative requires the exact teacher decision and scope.",
          "options": [
            "",
            "PENDING",
            "ACTUAL_RECORDED",
            "SEPARATELY_APPROVED_ALTERNATIVE"
          ]
        },
        {
          "id": "atomicity_limits",
          "label": "Limits of the atomicity observation",
          "kind": "textarea",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "State exactly which sequential failure points were exercised. Do not claim crash durability, reversible external side effects or general transaction coverage."
        },
        {
          "id": "concurrency_scope",
          "label": "What was and was not tested about concurrent requests",
          "kind": "textarea",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "Name untested schedules and isolation assumptions. No new production mutex, lock policy or load experiment is required for P02."
        },
        {
          "id": "remaining_checks",
          "label": "Checks not yet executed and reasons",
          "kind": "textarea",
          "max": 12000,
          "phase": "core",
          "default": "",
          "help": "List unexecuted checks or NONE with a reason. Do not convert missing dependencies into a PASS."
        },
        {
          "id": "observed_difference",
          "label": "Difference between prediction and observation",
          "kind": "textarea",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "Compare each preserved prediction with the actual witness. If no genuine run occurred record PENDING: reason and avoid calling source expectations observations."
        },
        {
          "id": "evidence_index",
          "label": "Reproducible evidence index",
          "kind": "textarea",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "Use one row per witness: ID | evidence class | fixture/request | command/source path | runtime | expected/observed state | pending reason. Distinguish source, model, genuine ORM/SQLite, local HTTP and actual Gemini."
        }
      ]
    },
    {
      "id": "gemini",
      "title": "Bounded Gemini review",
      "intro": "Use one sanitised claim and an independent witness. Agreement with Gemini is not the target.",
      "fields": [
        {
          "id": "gemini_state",
          "label": "Actual Gemini activity state",
          "kind": "select",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "ACTUAL_RECORDED declares an actual bounded Gemini interaction with an independent check. Synthetic practice remains pending. A selector cannot grant an alternative.",
          "options": [
            "",
            "PENDING",
            "ACTUAL_RECORDED",
            "SEPARATELY_APPROVED_ALTERNATIVE"
          ]
        },
        {
          "id": "gemini_context",
          "label": "Sanitised context and date",
          "kind": "textarea",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "State the small sanitised code or contract context. No passwords, tokens, cookies or private datasets."
        },
        {
          "id": "gemini_prompt",
          "label": "Relevant prompt only",
          "kind": "textarea",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "Copy only the relevant prompt, not the full conversation."
        },
        {
          "id": "gemini_claim",
          "label": "One claim selected for verification",
          "kind": "textarea",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "Quote or accurately restate one claim selected for audit."
        },
        {
          "id": "gemini_check",
          "label": "Independent witness and evidence class",
          "kind": "textarea",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "Give an independent command, test, diff or exact contract passage and the observed result. Name its evidence class."
        },
        {
          "id": "gemini_verdict",
          "label": "ACCEPTED / REJECTED / PARTIALLY ACCEPTED / UNKNOWN",
          "kind": "select",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "Choose ACCEPTED, REJECTED, PARTIALLY ACCEPTED or UNKNOWN on the evidence, not on confidence of wording.",
          "options": [
            "",
            "ACCEPTED",
            "REJECTED",
            "PARTIALLY ACCEPTED",
            "UNKNOWN"
          ]
        },
        {
          "id": "gemini_correction",
          "label": "Correction or justified NONE",
          "kind": "textarea",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "Give the minimal correction or NONE with a justification."
        },
        {
          "id": "gemini_limit",
          "label": "Limit of the verification",
          "kind": "textarea",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "State what your independent check does not establish."
        }
      ]
    },
    {
      "id": "adr",
      "title": "Required architecture decision record",
      "intro": "Required analysis, not a second full programming project. About 300–500 words plus a small client-effect table is a suggested scope.",
      "fields": [
        {
          "id": "adr_context",
          "label": "Decision context and invariant",
          "kind": "textarea",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "Use a sanitised semester-project context. Where undecided, label a provisional course-domain decision and when it will be revisited."
        },
        {
          "id": "adr_resources",
          "label": "Resource identity and intended public representation",
          "kind": "textarea",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "Identify the resource and its stable identity. Distinguish registration membership from a booking POST operation."
        },
        {
          "id": "adr_alternatives",
          "label": "At least two realistic alternatives",
          "kind": "textarea",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "Compare at least two realistic alternatives, including action-shaped endpoints and a membership resource where relevant. Do not merely list names."
        },
        {
          "id": "adr_decision",
          "label": "Chosen design and reason",
          "kind": "textarea",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "Choose and justify an option against stated criteria. A rejected Gemini proposal can be a sound decision."
        },
        {
          "id": "adr_transaction",
          "label": "Transaction boundary, reads, writes and failure policy",
          "kind": "textarea",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "Identify state that must change together, its owner, transaction membership and excluded side effects. Separate atomicity from concurrency and durability."
        },
        {
          "id": "adr_retry_table",
          "label": "Repeat-request effect and response table",
          "kind": "textarea",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "Use the P03 contract rows: collection GET; first member PUT; identical PUT; changed ticketType PUT; first DELETE; repeated DELETE; invalid query/body; missing parent. Add method/path, intended effect, expected response category, evidence class and remaining uncertainty. Discuss an uncertain response separately as a thought experiment unless actually observed."
        },
        {
          "id": "adr_evidence",
          "label": "Source or experiment evidence supporting the decision",
          "kind": "textarea",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "Cite contract paths, observed witnesses or a declared source-based comparison. Full P03 implementation is not required for this analysis."
        },
        {
          "id": "adr_consequences",
          "label": "Trade-offs and a condition for revisiting the decision",
          "kind": "textarea",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "Explain costs, operational limits and a condition for revisiting the decision. Do not assume Location is a retrievable endpoint in P02."
        }
      ]
    },
    {
      "id": "closing",
      "title": "Completion and individual declaration",
      "intro": "Save a truthful draft at minute 60. Finish P02 and the ADR before the separately configured deadline.",
      "fields": [
        {
          "id": "exit_state",
          "label": "Actual state at minute60 and at final export",
          "kind": "textarea",
          "max": 12000,
          "phase": "core",
          "default": "",
          "help": "At minute 60 record IMPLEMENTATION_PENDING, EVIDENCE_PENDING, ADR_PENDING or your actual state. The time limit does not produce a PASS."
        },
        {
          "id": "next_check",
          "label": "Next smallest unresolved check",
          "kind": "textarea",
          "max": 12000,
          "phase": "core",
          "default": "",
          "help": "Name the smallest useful next check or NONE with a reason."
        },
        {
          "id": "reflection",
          "label": "Mechanism-based reflection",
          "kind": "textarea",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "Explain one mechanism and which observation changed or confirmed your view."
        },
        {
          "id": "uncertainty",
          "label": "Remaining uncertainty",
          "kind": "textarea",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "State one specific untested assumption or boundary; it is not a generic confidence claim."
        },
        {
          "id": "authority_reference",
          "label": "Separately obtained teacher decision, when applicable",
          "kind": "textarea",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "Write NONE for the standard route. For a separate alternative start AUTHORISATION: and give teacher, date, decision reference, exact affected requirement and replacement evidence. The selector and checker cannot grant or authenticate that decision."
        },
        {
          "id": "declaration",
          "label": "Truthful individual-work and evidence declaration",
          "kind": "checkbox",
          "max": null,
          "phase": "final",
          "default": false,
          "help": "I performed or accurately attributed this work, kept prior predictions and distinguished source, measured, imported and synthetic evidence. I reviewed the imported draft where applicable. I included no secrets or private third-party data."
        },
        {
          "id": "privacy_check",
          "label": "Privacy review",
          "kind": "checkbox",
          "max": null,
          "phase": "final",
          "default": false,
          "help": "I reviewed the final PDF and relevant Gemini context for secrets, credentials, cookies, private third-party data and unrelated conversation content."
        },
        {
          "id": "upload_checklist",
          "label": "Final PDF and submission checklist",
          "kind": "textarea",
          "max": 12000,
          "phase": "final",
          "default": "",
          "help": "Record that the PDF opens, includes all seven sections, uses TW2026_S07_GROUP_Surname_Firstname.pdf and contains readable evidence. Upload exactly one PDF to the single S07 Assignment. Record the actual submission state separately; a generated file is not a confirmed submission."
        }
      ]
    }
  ],
  "maxExportBytes": 2000000,
  "legacyVersions": [
    "1.1.0"
  ],
  "legacyIds": [
    "surname",
    "given",
    "group",
    "kits",
    "os",
    "terminal",
    "node",
    "npm",
    "dependencies",
    "input_fixture",
    "prediction",
    "invariant",
    "edit_path",
    "initial_checks",
    "before_state",
    "unsafe_observation",
    "unsafe_limit",
    "operation_sequence",
    "transaction_witness",
    "success_state",
    "success_http",
    "callback_failure",
    "audit_failure",
    "rollback_state",
    "error_identity",
    "commit_boundary",
    "recovery",
    "invalid_outcomes",
    "fixture_identity",
    "actual_stack_state",
    "atomicity_limits",
    "concurrency_scope",
    "remaining_checks",
    "gemini_state",
    "gemini_context",
    "gemini_prompt",
    "gemini_claim",
    "gemini_check",
    "gemini_verdict",
    "gemini_correction",
    "gemini_limit",
    "adr_context",
    "adr_resources",
    "adr_alternatives",
    "adr_decision",
    "adr_transaction",
    "adr_retry_table",
    "adr_evidence",
    "adr_consequences",
    "exit_state",
    "next_check",
    "reflection",
    "uncertainty",
    "authority_reference",
    "declaration"
  ],
  "evidenceClasses": [
    "SOURCE_REASONING",
    "SOURCE_EXPECTATION",
    "MODULE_MODEL",
    "SYNTHETIC_PRACTICE",
    "GENUINE_ORM_SQLITE",
    "LOCAL_HTTP",
    "ACTUAL_GEMINI",
    "NATIVE_BROWSER",
    "NATIVE_WINDOWS",
    "NATIVE_MACOS",
    "NATIVE_WORD",
    "NOT_EXECUTED"
  ],
  "legacyEvidenceAliases": {
    "SOURCE_LINKED_MODEL": "MODULE_MODEL",
    "ADRMODULE_MODEL": "MODULE_MODEL",
    "ACTUAL_ORM_SQLITE": "GENUINE_ORM_SQLITE"
  },
  "compatibleVersions": [
    "1.2.0"
  ]
};
