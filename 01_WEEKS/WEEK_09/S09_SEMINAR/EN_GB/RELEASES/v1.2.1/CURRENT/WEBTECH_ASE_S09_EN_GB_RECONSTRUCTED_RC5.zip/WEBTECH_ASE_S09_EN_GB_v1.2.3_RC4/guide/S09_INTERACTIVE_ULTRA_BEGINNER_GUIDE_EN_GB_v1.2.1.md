# S09 — Routed Notes Application

Ultra-beginner student guide · v1.2.1 · Phase3 local remediation candidate with open runtime/platform gates.

No app, Node/npm, historical recipe, browser or network execution occurred while authoring this guide. Future commands are only for a separately qualified teaching environment.

## The 90-minute meeting

60 content minutes and30 logistics minutes; planned rather than cohort-measured. STOP at content minute 60. Full P01 source estimate 55–65, P03 estimate 40–55 and later P02 estimate 70–90 minutes remain honest continuation obligations.

| Minutes | Individual activity | Record fields |
| --- | --- | --- |
| 00–05 | Identity and two predictions | p01_prediction, actual_environment, package_identity, fixture |
| 05–12 | Map URL ownership and history | route_owner_map, history_policy |
| 12–30 | Implement within the one-file boundary | permitted_edit, pending_work |
| 30–38 | Observe one transition and one counterexample | p01_case_ledger, link_history_trace, p01_test_results, counterexample_record |
| 38–44 | Ask Gemini about one bounded claim | gemini_prompt, gemini_claim, gemini_mode, record_status_ledger |
| 44–49 | Independently check and qualify the claim | independent_check, gemini_verdict, correction_limit |
| 49–55 | Plan required P03 and separate capstone transfer | p03_prediction, p03_case_ledger, p02_transfer_map |
| 55–60 | Save the truthful draft and stop | pending_work, declaration, pre_export_checklist, exit_ticket |

## 01. Identify the download and keep the original

Use the student ZIP supplied for S09 v1.2.1. A teacher, QA or intake archive is private and is not the student working package. Reading this guide does not authorise software installation, publication or a live institutional operation. Application commands below are for a later separately qualified teaching environment; they were not executed while authoring this guide.

![Illustrative interface diagram showing the unchanged student ZIP, a new empty extraction target and the beginner guide entry with its exact filename in the caption.](assets/IMG-S09-01.svg)

Illustrative interface diagram. Exact entry: guide/S09_INTERACTIVE_ULTRA_BEGINNER_GUIDE_EN_GB_v1.2.1.html. These are worked example paths, not a screenshot of your computer.

### Step01.1

**WHERE YOU ARE** — The delivery message in your browser.

**WHAT TO FIND** — The link named TW2026_S09_STUDENT_EN_GB_v1.2.1_LOCAL_FINAL_SOURCE_ONLY.zip.

**EXACT ACTION** — Click that exact student ZIP link once.

**WHAT YOU SHOULD SEE** — A download starts or your browser asks where to save the file.

**WHAT TO RECORD** — Record the exact filename, not a guessed version from an older folder.

**DO NOT CONTINUE UNLESS** — The link is the student ZIP for S09 v1.2.1.

**IF YOU DO NOT SEE THIS** — Return to the delivery message and locate the exact student filename.

**STOP CONDITION** — The only available link is private, an older version or a different seminar.

**CONTINUE WITH** — 01.2

Form locators: package_identity.

### Step01.2

**WHERE YOU ARE** — Your browser Save As window, if shown.

**WHAT TO FIND** — The folder D:\#___MY_SPACE\Downloads.

**EXACT ACTION** — Click Save after selecting that folder.

**WHAT YOU SHOULD SEE** — The downloaded ZIP appears in the selected folder after completion.

**WHAT TO RECORD** — Keep the original ZIP unchanged. Do not rename it to another version.

**DO NOT CONTINUE UNLESS** — The download has finished; a partial-download suffix is absent.

**IF YOU DO NOT SEE THIS** — Open your browser Downloads list and use Show in folder after completion.

**STOP CONDITION** — The browser reports a failed or incomplete transfer.

**CONTINUE WITH** — 01.3

Form locators: package_identity.

### Step01.3

**WHERE YOU ARE** — File Explorer at the downloaded ZIP.

**WHAT TO FIND** — The exact S09 v1.2.1 filename and its .zip extension.

**EXACT ACTION** — Select the ZIP once without opening it.

**WHAT YOU SHOULD SEE** — The selected file is the original archive; it is still archived.

**WHAT TO RECORD** — Record the actual filename. A filename alone is not a PACKAGE_ID or a measured SHA.

**DO NOT CONTINUE UNLESS** — You can identify the student ZIP without guessing from a generic name.

**IF YOU DO NOT SEE THIS** — Enable the visible File name extensions option if the extension is hidden; its location may vary.

**STOP CONDITION** — The file is a partial transfer or the filename disagrees with the supplied link.

**CONTINUE WITH** — 02.1

Form locators: package_identity.

## 02. Extract into a new short empty folder

The worked Windows path is D:\WTS09. If that folder already contains work, use a new folder such as D:\WTS09_B and replace the root consistently in every later path. Do not overwrite or delete an earlier exercise. The extracted student package root contains guide, form, projects, portfolio and capstone.

![Illustrative interface diagram showing the unchanged student ZIP, a new empty extraction target and the beginner guide entry with its exact filename in the caption.](assets/IMG-S09-01.svg)

Illustrative interface diagram. Exact entry: guide/S09_INTERACTIVE_ULTRA_BEGINNER_GUIDE_EN_GB_v1.2.1.html. These are worked example paths, not a screenshot of your computer.

### Step02.1

**WHERE YOU ARE** — File Explorer with the original student ZIP selected.

**WHAT TO FIND** — The ZIP context-menu command Extract All / Extract all.

**EXACT ACTION** — Right-click the selected ZIP.

**WHAT YOU SHOULD SEE** — A context menu opens for that ZIP.

**WHAT TO RECORD** — No observation needs a screenshot yet. Retain the original archive identity.

**DO NOT CONTINUE UNLESS** — The menu belongs to the ZIP rather than a previous extracted folder.

**IF YOU DO NOT SEE THIS** — Select the exact ZIP again before reopening its context menu.

**STOP CONDITION** — The selected item is not the supplied ZIP.

**CONTINUE WITH** — 02.2

Form locators: package_identity.

### Step02.2

**WHERE YOU ARE** — The selected ZIP context menu.

**WHAT TO FIND** — Extract All / Extract all; Windows may show it in the main or extended menu.

**EXACT ACTION** — Click the extraction command.

**WHAT YOU SHOULD SEE** — An extraction destination window appears.

**WHAT TO RECORD** — Record an unexpected extraction error verbatim.

**DO NOT CONTINUE UNLESS** — You can inspect the destination before starting extraction.

**IF YOU DO NOT SEE THIS** — If the command is unavailable, ask for the permitted archive-opening route; do not install an archiver.

**STOP CONDITION** — No authorised extraction route is available.

**CONTINUE WITH** — 02.3

Form locators: environment_limit.

### Step02.3

**WHERE YOU ARE** — The extraction destination window.

**WHAT TO FIND** — The destination path box.

**EXACT ACTION** — Replace its value with D:\WTS09, or your chosen new empty short folder.

**WHAT YOU SHOULD SEE** — The target shows the selected new folder, not the repository or an old project.

**WHAT TO RECORD** — Record your actual root folder for subsequent paths.

**DO NOT CONTINUE UNLESS** — The target does not already contain prior work.

**IF YOU DO NOT SEE THIS** — Choose a different new folder such as D:\WTS09_B if the first target exists.

**STOP CONDITION** — You would overwrite existing files or extract into a repository.

**CONTINUE WITH** — 02.4

Form locators: actual_environment.

### Step02.4

**WHERE YOU ARE** — The extraction destination window with the new target selected.

**WHAT TO FIND** — The Extract button.

**EXACT ACTION** — Click Extract once.

**WHAT YOU SHOULD SEE** — Extraction completes and the target folder can be opened.

**WHAT TO RECORD** — Record any exact error rather than deleting the original ZIP.

**DO NOT CONTINUE UNLESS** — Extraction has completed without an error.

**IF YOU DO NOT SEE THIS** — Preserve the ZIP and failed extraction; report the error and retry only into a new folder.

**STOP CONDITION** — The archive is corrupt, unsafe or still incomplete.

**CONTINUE WITH** — 02.5

Form locators: environment_limit.

### Step02.5

**WHERE YOU ARE** — File Explorer in the extraction target.

**WHAT TO FIND** — The guide folder alongside form, projects, portfolio and capstone.

**EXACT ACTION** — Open the guide folder.

**WHAT YOU SHOULD SEE** — The beginner HTML and seven inspectable SVG files under assets are visible.

**WHAT TO RECORD** — Record the actual package root. A possible single wrapper folder is part of that root.

**DO NOT CONTINUE UNLESS** — The expected folders are present together.

**IF YOU DO NOT SEE THIS** — If there is one wrapper folder, enter it once and use that location as the root; do not reconstruct the tree manually.

**STOP CONDITION** — Required folders are missing or belong to another version.

**CONTINUE WITH** — 03.1

Form locators: package_identity, actual_environment.

## 03. Open the offline beginner guide

This HTML is the default entry point. Its CSS, JavaScript and essential diagrams are inside the file; external websites are optional later activity routes. A Vite project index.html is not the offline guide and double-clicking it is not a React run.

### Step03.1

**WHERE YOU ARE** — File Explorer in the extracted guide folder.

**WHAT TO FIND** — The file S09_INTERACTIVE_ULTRA_BEGINNER_GUIDE_EN_GB_v1.2.1.html.

**EXACT ACTION** — Double-click that HTML file.

**WHAT YOU SHOULD SEE** — Your browser displays S09 — Routed Notes Application and v1.2.1.

**WHAT TO RECORD** — Record the guide/package version in package_identity.

**DO NOT CONTINUE UNLESS** — You opened the guide file, not a project index.html.

**IF YOU DO NOT SEE THIS** — Return to guide and open the exact beginner HTML; do not move individual files out of the package.

**STOP CONDITION** — The file is missing or the header shows a different seminar/version.

**CONTINUE WITH** — 03.2

Form locators: package_identity.

### Step03.2

**WHERE YOU ARE** — The opened local beginner guide.

**WHAT TO FIND** — The address bar beginning file:// and this guide header.

**EXACT ACTION** — Read the address bar and header.

**WHAT YOU SHOULD SEE** — The guide is local. Reading-mode content remains visible without contacting a server.

**WHAT TO RECORD** — No app run is implied by file://. Record NOT_EXECUTED for unrun app witnesses.

**DO NOT CONTINUE UNLESS** — The shown page is the local guide rather than an old localhost app tab.

**IF YOU DO NOT SEE THIS** — Use the guide tab and close an irrelevant tab only if it is your own unneeded tab.

**STOP CONDITION** — You cannot identify which tab is the guide.

**CONTINUE WITH** — 03.3

Form locators: evidence_class.

### Step03.3

**WHERE YOU ARE** — The guide contents list.

**WHAT TO FIND** — The link Prepare the exact project in your editor.

**EXACT ACTION** — Click that contents link.

**WHAT YOU SHOULD SEE** — The guide moves to module04; the persistent header still identifies S09 v1.2.1.

**WHAT TO RECORD** — Progress boxes track reading only and never certify an experiment.

**DO NOT CONTINUE UNLESS** — You can return to Start here and the contents using the visible navigation.

**IF YOU DO NOT SEE THIS** — Use the browser Find command for the module title if navigation is unavailable; all content is present in reading order.

**STOP CONDITION** — The guide content is unreadable or absent.

**CONTINUE WITH** — 04.1

Form locators: environment_limit.

Optional progress storage is off by default. Turning it on stores only checked module IDs at this file origin. A visible storage error means the browser did not save progress; it does not erase or save form evidence.

## 04. Prepare the exact project in your editor

The Windows example uses an already installed authorised VS Code. Another permitted editor can be used with the same file boundary. Do not install an editor, extension or dependency during the timed route. Historical README wording saying Reference or npm install does not change the incomplete starter or grant installation authority.

![Illustrative interface diagram separating URL noteId, the addressed note2 record and the local unsaved title/body draft.](assets/IMG-S09-02.svg)

Illustrative interface diagram. The URL selects the addressed record; editable title/body remain a local draft until a valid write. P01 storage is volatile, with no durability or authorisation claim.

### Step04.1

**WHERE YOU ARE** — Your existing editor window.

**WHAT TO FIND** — The File menu.

**EXACT ACTION** — Click File.

**WHAT YOU SHOULD SEE** — The editor file menu is visible.

**WHAT TO RECORD** — Record an unavailable editor as an environment block.

**DO NOT CONTINUE UNLESS** — The editor is already available in the authorised teaching environment.

**IF YOU DO NOT SEE THIS** — Ask for the established editor route; preserve a source-reading draft if unavailable.

**STOP CONDITION** — An installation or extension acquisition would be needed.

**CONTINUE WITH** — 04.2

Form locators: actual_environment, environment_limit.

### Step04.2

**WHERE YOU ARE** — The editor File menu.

**WHAT TO FIND** — Open Folder / Open folder; labels may differ by editor/version.

**EXACT ACTION** — Click the folder-opening command.

**WHAT YOU SHOULD SEE** — A folder chooser appears.

**WHAT TO RECORD** — You are choosing a folder, not creating a new project.

**DO NOT CONTINUE UNLESS** — The command opens an existing folder.

**IF YOU DO NOT SEE THIS** — Use the equivalent visible existing-folder command in the permitted editor.

**STOP CONDITION** — You cannot identify the command without guessing a project-creation route.

**CONTINUE WITH** — 04.3

Form locators: actual_environment.

### Step04.3

**WHERE YOU ARE** — The editor folder chooser.

**WHAT TO FIND** — Your extracted student package root, for example D:\WTS09.

**EXACT ACTION** — Select that root and confirm Select Folder / Open.

**WHAT YOU SHOULD SEE** — The editor Explorer shows guide, form, projects, portfolio and capstone.

**WHAT TO RECORD** — Record the actual root. Accept a trust prompt only under the teacher-approved local workspace policy.

**DO NOT CONTINUE UNLESS** — The opened folder is the extracted supplied package.

**IF YOU DO NOT SEE THIS** — Cancel and choose the correct extracted folder if the tree is wrong.

**STOP CONDITION** — The workspace is another project or an unreviewed download.

**CONTINUE WITH** — 04.4

Form locators: actual_environment, package_identity.

### Step04.4

**WHERE YOU ARE** — The editor Explorer at the supplied package.

**WHAT TO FIND** — projects/p01/student/src/NotesApp.jsx.

**EXACT ACTION** — Open that exact file.

**WHAT YOU SHOULD SEE** — The supplied incomplete NotesApp starter and focused TODOs are visible.

**WHAT TO RECORD** — Write the full allowed path in permitted_edit. Do not copy a private reference.

**DO NOT CONTINUE UNLESS** — The tab path ends projects/p01/student/src/NotesApp.jsx.

**IF YOU DO NOT SEE THIS** — Use the editor file search with the full relative path, then inspect the path before editing.

**STOP CONDITION** — You opened a store, test, reference, preview or another seminar file.

**CONTINUE WITH** — 04.5

Form locators: permitted_edit.

### Step04.5

**WHERE YOU ARE** — The open P01 NotesApp.jsx tab.

**WHAT TO FIND** — The adjacent P01 CONTRACT.md and spec.md in the supplied tree.

**EXACT ACTION** — Read the active contract before implementation.

**WHAT YOU SHOULD SEE** — The complete list/detail/new/edit/redirect/missing/catch-all and controlled-form obligations are explicit.

**WHAT TO RECORD** — List unfinished obligations in pending_work; an 18-minute class segment is not the whole project.

**DO NOT CONTINUE UNLESS** — You understand the one-file boundary and the complete task.

**IF YOU DO NOT SEE THIS** — Read the protected source and form owner map without changing it; ask about an unclear obligation.

**STOP CONDITION** — You would modify tests/store/CSS/package files to make a check succeed.

**CONTINUE WITH** — 05.1

Form locators: permitted_edit, pending_work.

## 05. Identify the qualified terminal and actual versions

The source prescribes Node 24.21.0/npm 11.19.0; these strings are not proof of availability or installation. Record only versions you actually observe. Windows commands below assume PowerShell; for an already authorised macOS/Linux shell use pwd instead of Get-Location and the same Node/npm commands. No platform acceptance is implied.

### Step05.1

**WHERE YOU ARE** — The editor with the extracted root open.

**WHAT TO FIND** — Terminal menu → New Terminal / New terminal.

**EXACT ACTION** — Open a new integrated terminal using the visible menu command.

**WHAT YOU SHOULD SEE** — A terminal panel appears with a prompt.

**WHAT TO RECORD** — Record terminal shell and operating system in actual_environment.

**DO NOT CONTINUE UNLESS** — The terminal belongs to this workspace and is already provisioned.

**IF YOU DO NOT SEE THIS** — Use the teacher-approved terminal application if the editor has no integrated terminal.

**STOP CONDITION** — A terminal, runtime or dependency would need installation.

**CONTINUE WITH** — 05.2

Form locators: actual_environment, environment_limit.

### Step05.2

**WHERE YOU ARE** — The terminal prompt.

**WHAT TO FIND** — The directory-changing command below.

**EXACT ACTION** — Run the exact cd command for your actual extracted root.

**WHAT YOU SHOULD SEE** — The terminal enters the P01 student directory or reports a path error.

**WHAT TO RECORD** — Record the actual full project path, preserving spaces if present.

**DO NOT CONTINUE UNLESS** — The project directory contains package.json, src and tests.

**IF YOU DO NOT SEE THIS** — Replace only the root path with your actual extracted location; do not use an old folder.

**STOP CONDITION** — The directory is missing or belongs to a different package.

**CONTINUE WITH** — 05.3

Form locators: actual_environment, permitted_edit.

```text
cd "D:\WTS09\projects\p01\student"
```

### Step05.3

**WHERE YOU ARE** — The terminal inside the P01 directory.

**WHAT TO FIND** — The current-location command for your shell.

**EXACT ACTION** — Run Get-Location in PowerShell, or pwd in the authorised shell.

**WHAT YOU SHOULD SEE** — The printed path ends projects/p01/student.

**WHAT TO RECORD** — Copy that observed path into actual_environment.

**DO NOT CONTINUE UNLESS** — The printed directory is exactly P01 student.

**IF YOU DO NOT SEE THIS** — Return to 05.2 and correct the root path.

**STOP CONDITION** — You cannot confirm the working directory.

**CONTINUE WITH** — 05.4

Form locators: actual_environment.

```text
Get-Location
```

### Step05.4

**WHERE YOU ARE** — The qualified terminal in P01.

**WHAT TO FIND** — The Node version command.

**EXACT ACTION** — Run node --version once.

**WHAT YOU SHOULD SEE** — An actual version string appears, or the command is unavailable.

**WHAT TO RECORD** — Record the output verbatim; unavailable means BLOCKED/NOT_EXECUTED for dependent work.

**DO NOT CONTINUE UNLESS** — Runtime qualification has been established separately and the actual version is recorded.

**IF YOU DO NOT SEE THIS** — Preserve the command/error and ask for the already-authorised teaching environment; use source-reading fallback.

**STOP CONDITION** — You would acquire or upgrade Node to remove the error.

**CONTINUE WITH** — 05.5

Form locators: actual_environment, environment_limit.

```text
node --version
```

### Step05.5

**WHERE YOU ARE** — The same qualified terminal.

**WHAT TO FIND** — The npm version command.

**EXACT ACTION** — Run npm --version once.

**WHAT YOU SHOULD SEE** — An actual version string appears, or an exact error is shown.

**WHAT TO RECORD** — Record the observed npm version/error independently from Node.

**DO NOT CONTINUE UNLESS** — The actual environment is documented and dependency availability is separately qualified.

**IF YOU DO NOT SEE THIS** — Record the error and keep application observations NOT_EXECUTED.

**STOP CONDITION** — You would run npm install/npm ci or download dependencies during this guide route.

**CONTINUE WITH** — 06.1

Form locators: actual_environment, environment_limit.

```text
npm --version
```

No install, upgrade or dependency acquisition is hidden in a preflight. A missing command, parser error, timeout, crash or reporter failure is not the intended unavailable-starter objective failure.

## 06. Write two predictions before any experiment

Use the S09 form in a second local tab so this guide stays open. Its HTML route is text-only. Record two numbered P01 predictions before running or observing. Each includes initial fixture/history, action, expected result and an observation that could falsify it. Do not revise a prediction afterwards to fit the output.

![Illustrative interface diagram separating URL noteId, the addressed note2 record and the local unsaved title/body draft.](assets/IMG-S09-02.svg)

Illustrative interface diagram. The URL selects the addressed record; editable title/body remain a local draft until a valid write. P01 storage is volatile, with no durability or authorisation claim.

### Step06.1

**WHERE YOU ARE** — The local guide tab.

**WHAT TO FIND** — The Open S09 evidence form link below.

**EXACT ACTION** — Open the evidence form in a second tab.

**WHAT YOU SHOULD SEE** — The form identifies S09 v1.2.1 and the 54-field schema.

**WHAT TO RECORD** — Enter identity/date/package/environment truthfully; leave unobserved results blank or explicitly pending.

**DO NOT CONTINUE UNLESS** — You opened the extracted form beside the guide, not an online generic form.

**IF YOU DO NOT SEE THIS** — From File Explorer open form/FORM_S09_EN_GB.html in the extracted package.

**STOP CONDITION** — The form file is missing or identifies a different version.

**CONTINUE WITH** — 06.2

Form locators: student_identity, session_date, seminar_id, package_identity, actual_environment.

### Step06.2

**WHERE YOU ARE** — The S09 form Predictions section.

**WHAT TO FIND** — p01_prediction.

**EXACT ACTION** — Write Prediction1 for a valid trimmed create from seed 1/2 and an explicit list→new history.

**WHAT YOU SHOULD SEE** — Your own text specifies expected ID/destination/history and a falsifier before running.

**WHAT TO RECORD** — Number the prediction and retain its before-run status; use your own words.

**DO NOT CONTINUE UNLESS** — The prediction distinguishes a destination from the history effect.

**IF YOU DO NOT SEE THIS** — Read the P01 specification and name the missing initial condition before running.

**STOP CONDITION** — You already observed the result and would label a retrospective note as a prediction.

**CONTINUE WITH** — 06.3

Form locators: p01_prediction, fixture, history_policy.

### Step06.3

**WHERE YOU ARE** — The same p01_prediction field.

**WHAT TO FIND** — A second numbered prediction with a distinct rejected or edge case.

**EXACT ACTION** — Write Prediction2 for a whitespace-only title and its no-write/no-navigation boundary.

**WHAT YOU SHOULD SEE** — The second prediction includes what error/state would be visible and what would falsify no-write.

**WHAT TO RECORD** — Keep a separate action/expected/falsifier for case 2; do not use two paraphrases of case 1.

**DO NOT CONTINUE UNLESS** — Two falsifiable before-run predictions are preserved.

**IF YOU DO NOT SEE THIS** — Use a missing-note or target-change case if the teacher has explicitly selected that distinct second case.

**STOP CONDITION** — A result is copied from a neighbour or retrospective output.

**CONTINUE WITH** — 07.1

Form locators: p01_prediction, form_owner_map, record_status_ledger.

## 07. Initialise an exact route and record the source boundary

P01 begins as an intentionally unavailable route boundary. You must implement the complete allowed-file objective yourself; this guide does not include a completed NotesApp. The class implementation segment is 18 minutes, while the source estimate for the full task is 55–65 minutes. A truthful incomplete record remains a draft.

### Step07.1

**WHERE YOU ARE** — The separately qualified terminal in projects/p01/student.

**WHAT TO FIND** — The baseline command.

**EXACT ACTION** — Run npm run test:baseline once.

**WHAT YOU SHOULD SEE** — The named baseline suite produces actual output; retain its real status.

**WHAT TO RECORD** — Record command, exact suite/assertion names, output locator and status in p01_test_results.

**DO NOT CONTINUE UNLESS** — You can distinguish baseline outcome from an objective failure.

**IF YOU DO NOT SEE THIS** — Record a startup/dependency/parser/reporter block verbatim rather than calling it expected.

**STOP CONDITION** — A baseline is blocked or unhealthy for an unresolved environment/infrastructure reason.

**CONTINUE WITH** — 07.2

Form locators: p01_test_results, evidence_class, record_status_ledger.

```text
npm run test:baseline
```

### Step07.2

**WHERE YOU ARE** — The same P01 terminal.

**WHAT TO FIND** — The objective command.

**EXACT ACTION** — Run npm run test:objective once when the environment is qualified.

**WHAT YOU SHOULD SEE** — Actual named assertions identify current objective behaviour; the unavailable starter may fail at its documented UI boundary.

**WHAT TO RECORD** — Retain exact failed assertions and source/test identity. Any failure is not automatically the intended learner failure.

**DO NOT CONTINUE UNLESS** — You have retained the actual output and classified it honestly.

**IF YOU DO NOT SEE THIS** — If the starter is still incomplete, list missing behaviours and continue allowed-file implementation before later route observations.

**STOP CONDITION** — The failure is a parser/command/dependency/timeout/crash/reporter fault.

**CONTINUE WITH** — 07.3

Form locators: p01_test_results, p01_completion, pending_work.

```text
npm run test:objective
```

### Step07.3

**WHERE YOU ARE** — The qualified P01 terminal after saving your allowed-file work.

**WHAT TO FIND** — The dev command.

**EXACT ACTION** — Run npm run dev.

**WHAT YOU SHOULD SEE** — A server process starts and prints a local address, or reports its actual error.

**WHAT TO RECORD** — Record the exact printed URL and command. Keep this terminal for later Ctrl+C.

**DO NOT CONTINUE UNLESS** — The process starts without an unresolved environment error.

**IF YOU DO NOT SEE THIS** — Preserve the output and use source-only fallback if the server cannot start.

**STOP CONDITION** — You would reinstall dependencies, alter the protected Vite configuration or expose the server externally.

**CONTINUE WITH** — 07.4

Form locators: actual_environment, p01_test_results, environment_limit.

```text
npm run dev
```

### Step07.4

**WHERE YOU ARE** — The printed P01 dev URL in your terminal.

**WHAT TO FIND** — That exact local URL, including its actual port.

**EXACT ACTION** — Open the printed URL in a dedicated browser tab.

**WHAT YOU SHOULD SEE** — The currently implemented app or unavailable starter is visible.

**WHAT TO RECORD** — Record initial address, visible state and source identity; opening a URL is not a completed objective.

**DO NOT CONTINUE UNLESS** — You can identify the tab and current app state.

**IF YOU DO NOT SEE THIS** — Use the exact printed address; do not invent a default port or open project index.html through file://.

**STOP CONDITION** — The page is another application, remote service or stale server.

**CONTINUE WITH** — 07.5

Form locators: direct_url_trace, evidence_class, environment_limit.

### Step07.5

**WHERE YOU ARE** — The dedicated running P01 browser tab.

**WHAT TO FIND** — The address bar, preserving the printed origin.

**EXACT ACTION** — Navigate to that origin followed by /notes/1.

**WHAT YOU SHOULD SEE** — A completed implementation shows addressed seed1; an incomplete route shows its actual current state.

**WHAT TO RECORD** — Record exact URL, noteId, title/body, fixture lifetime and class. The expected seed title is URL state.

**DO NOT CONTINUE UNLESS** — You record what appeared, including failures; you do not overwrite observed with expected.

**IF YOU DO NOT SEE THIS** — If the route is incomplete, retain the failure and continue only NotesApp.jsx work outside the fixed content clock as required.

**STOP CONDITION** — You would treat a missing UI as a successful direct-start witness.

**CONTINUE WITH** — 07.5a

Form locators: direct_url_trace, fixture, p01_case_ledger.

### Step07.5a

**WHERE YOU ARE** — The same P01 detail tab after the disclosed direct start at /notes/1.

**WHAT TO FIND** — The declarative Back to notes link required in the detail view.

**EXACT ACTION** — Activate Back to notes once.

**WHAT YOU SHOULD SEE** — The address becomes /notes and the list view contains the semantic New note link, or the actual incomplete result appears.

**WHAT TO RECORD** — Record this detail-to-list transition and the actual starting history for the following list-to-new experiment; do not claim an invented exact stack.

**DO NOT CONTINUE UNLESS** — The actual /notes list state and its source/store lifetime are identified before selecting New note.

**IF YOU DO NOT SEE THIS** — If the link or list is absent, keep the actual failure and implement only the missing NotesApp.jsx obligation before a later disclosed repeat.

**STOP CONDITION** — You would silently substitute a different tab, reload or assumed history for this recorded transition.

**CONTINUE WITH** — 08.1

Form locators: direct_url_trace, link_history_trace, p01_case_ledger.

A Vite direct start, a MemoryRouter initialization and production document delivery are different witnesses. A fresh store loses newly created notes by design; no durable server storage is proved.

## 08. Observe blank rejection and a trimmed submission

Work only in NotesApp.jsx. Before each observation, record the initial route/store/history and your own case ID. The expected behaviours below come from the specification, not from an application run performed for this package. Do not modify the store or tests to add logging; a named existing test or separately authorised witness can establish calls.

![Illustrative planned history comparison: push gives notes, new and detail3 with Back to new; replace gives notes and detail3 with Back to notes. This is not an actual trace.](assets/IMG-S09-03.svg)

Illustrative interface diagram. Planned fresh-seed comparison only: both policies can reach /notes/3, while Back exposes /notes/new after push and /notes after replace. No actual browser run or assessed code is shown.

### Step08.1

**WHERE YOU ARE** — The running P01 list route in your dedicated tab.

**WHAT TO FIND** — The semantic New note link in your own implementation.

**EXACT ACTION** — Activate New note once.

**WHAT YOU SHOULD SEE** — The address becomes /notes/new and the shared controlled new form is visible, or the actual incomplete result appears.

**WHAT TO RECORD** — Record the transition and initial blank form in p01_case_ledger.

**DO NOT CONTINUE UNLESS** — You have an actual observed route/form or an honestly recorded failure.

**IF YOU DO NOT SEE THIS** — If New note is absent, implement the missing obligation inside NotesApp.jsx and retest later.

**STOP CONDITION** — You would copy a private reference or modify protected files to bypass the missing route.

**CONTINUE WITH** — 08.2

Form locators: p01_case_ledger, link_history_trace.

### Step08.2

**WHERE YOU ARE** — The P01 new form.

**WHAT TO FIND** — The title input with its visible accessible label.

**EXACT ACTION** — Enter only spaces in the title field.

**WHAT YOU SHOULD SEE** — The controlled title contains the whitespace input; no submit has occurred.

**WHAT TO RECORD** — Retain the exact input for the rejected case.

**DO NOT CONTINUE UNLESS** — You can identify title separately from body and route ID.

**IF YOU DO NOT SEE THIS** — Use your implemented label/accessibility relation to locate title; fix that relation in NotesApp.jsx if absent.

**STOP CONDITION** — You cannot tell which input is title.

**CONTINUE WITH** — 08.3

Form locators: p01_case_ledger, form_owner_map.

### Step08.3

**WHERE YOU ARE** — The new form with a whitespace-only title.

**WHAT TO FIND** — Your form submit button.

**EXACT ACTION** — Submit the blank-title case once.

**WHAT YOU SHOULD SEE** — Specification expectation: accessible error, no store write and no navigation; record the actual outcome.

**WHAT TO RECORD** — Record error text, address before/after and a no-write witness with its class. UI appearance alone does not prove zero calls.

**DO NOT CONTINUE UNLESS** — The observation is retained even if it contradicts the prediction.

**IF YOU DO NOT SEE THIS** — Use the named original validation assertion or a separately declared witness; otherwise label the no-call inference SOURCE/UNKNOWN.

**STOP CONDITION** — You would report zero calls without a witness or relabel a runtime error as validation.

**CONTINUE WITH** — 08.4

Form locators: p01_case_ledger, create_trace, record_status_ledger.

### Step08.4

**WHERE YOU ARE** — The same form after the rejected attempt.

**WHAT TO FIND** — The title input.

**EXACT ACTION** — Replace its value with two leading/trailing spaces around Budget note.

**WHAT YOU SHOULD SEE** — The controlled field visibly contains your valid test title; body may remain blank or use a separately recorded value.

**WHAT TO RECORD** — Record the exact title/body submitted in your case ledger.

**DO NOT CONTINUE UNLESS** — Your values contain no personal or institutional record.

**IF YOU DO NOT SEE THIS** — Use a small fabricated teaching value rather than copying private business data.

**STOP CONDITION** — The input includes private records or credentials.

**CONTINUE WITH** — 08.5

Form locators: p01_case_ledger, privacy_check.

### Step08.5

**WHERE YOU ARE** — The new form with the valid recorded input.

**WHAT TO FIND** — The form submit button.

**EXACT ACTION** — Submit the valid case once.

**WHAT YOU SHOULD SEE** — Specification expectation: one trimmed create and navigation to the returned note ID; record actual ID/content/address.

**WHAT TO RECORD** — Record source/test identity, input/output and locator in create_trace. Fresh seed 1/2 has nextId 3; a reused store may have a different ID.

**DO NOT CONTINUE UNLESS** — The ID comes from the actual returned resource or a qualified witness, not an assumption from a prior run.

**IF YOU DO NOT SEE THIS** — If save fails, keep the exact failure and draft; do not invent a successful ID.

**STOP CONDITION** — You would send body-owned id data or change the protected store.

**CONTINUE WITH** — 09.1

Form locators: create_trace, p01_case_ledger, evidence_index.

Also complete the full edit contract at /notes/2/edit, trimmed update, preserved addressed ID, declarative Cancel without writes, shared NoteForm, stable missing note and unknown route. These remain whole-task obligations even when the class segment ends.

## 09. Discriminate Back/Forward and a changed edit target

The desired create witness begins with a documented list entry followed by new in the same running router. A final detail URL alone cannot prove replace. Preserve the initial history construction in your own record. Regular browser Back/Forward is a user experiment; manual window/history routing inside the assessed implementation is forbidden.

![Illustrative planned history comparison: push gives notes, new and detail3 with Back to new; replace gives notes and detail3 with Back to notes. This is not an actual trace.](assets/IMG-S09-03.svg)

Illustrative interface diagram. Planned fresh-seed comparison only: both policies can reach /notes/3, while Back exposes /notes/new after push and /notes after replace. No actual browser run or assessed code is shown.

### Step09.1

**WHERE YOU ARE** — The P01 detail view after a valid create from the documented list→new history.

**WHAT TO FIND** — The browser Back button.

**EXACT ACTION** — Click Back once.

**WHAT YOU SHOULD SEE** — Record the actual address and view. The intended replacement policy returns to the earlier list instead of the submitted new form.

**WHAT TO RECORD** — Record initial history, action, address/view and evidence locator in link_history_trace.

**DO NOT CONTINUE UNLESS** — The initial history and create event are known; you did not start in an unrelated tab.

**IF YOU DO NOT SEE THIS** — Repeat the witness only after establishing and recording a genuine initial list→new sequence in a fresh qualified run.

**STOP CONDITION** — You infer replacement from the final URL without observing history.

**CONTINUE WITH** — 09.2

Form locators: link_history_trace, counterexample_record, p01_case_ledger.

### Step09.2

**WHERE YOU ARE** — The same browser tab after the recorded Back action.

**WHAT TO FIND** — The browser Forward button.

**EXACT ACTION** — Click Forward once.

**WHAT YOU SHOULD SEE** — Record actual address/view; the intended policy returns to the created detail.

**WHAT TO RECORD** — Retain the Back and Forward pair rather than a single destination screenshot.

**DO NOT CONTINUE UNLESS** — This is the same tab and running store lifetime.

**IF YOU DO NOT SEE THIS** — Record an unavailable Forward action honestly and explain the history precondition.

**STOP CONDITION** — A newly opened tab or reset store is passed off as the same history.

**CONTINUE WITH** — 09.3

Form locators: link_history_trace, p01_case_ledger.

### Step09.3

**WHERE YOU ARE** — The P01 tab in its same running router.

**WHAT TO FIND** — The address bar with the correct printed origin.

**EXACT ACTION** — Navigate to the origin followed by /notes/2/edit.

**WHAT YOU SHOULD SEE** — The addressed note 2 edit view should initialise Controlled forms values; record actual fields.

**WHAT TO RECORD** — Record noteId 2 and initial draft in edit_trace. A full document reload creates a new store lifetime and must be stated.

**DO NOT CONTINUE UNLESS** — You identify both route target and draft values.

**IF YOU DO NOT SEE THIS** — If a missing or stale draft appears, record it and fix only the allowed component.

**STOP CONDITION** — You mirror noteId into an independent stale state or overwrite another note.

**CONTINUE WITH** — 09.4

Form locators: edit_trace, form_owner_map, p01_case_ledger.

### Step09.4

**WHERE YOU ARE** — Your planned same-router edit-target transition witness.

**WHAT TO FIND** — The named supplementary or original target-change test and its controlled start.

**EXACT ACTION** — Run the selected named target-change witness only in the separately qualified environment.

**WHAT YOU SHOULD SEE** — Record whether edit1→edit2 reinitialises draft without remounting the whole app or writing.

**WHAT TO RECORD** — Keep test name, fixture, source identity and REACT_TEST class; an address-bar reload alone does not prove this same-router property.

**DO NOT CONTINUE UNLESS** — The exact witness establishes the transition it claims and protected tests remain unchanged.

**IF YOU DO NOT SEE THIS** — Record NOT_EXECUTED if that witness is unavailable; retain the source contract separately.

**STOP CONDITION** — You invent a same-router transition from two unrelated document loads.

**CONTINUE WITH** — 10.1

Form locators: edit_trace, p01_test_results, p01_case_ledger, reflection_limit.

Finish and record root redirect replacement, semantic list/empty/detail, /notes/99 and /notes/99/edit missing-resource views, /unknown client catch-all, cancel no-write and edit replacement. The case table below provides exact named coverage without a completed implementation.

## 10. Collect a method/Accept/body/log trace for P03

P03 is required later individual work in the same S09 PDF; its source estimate is 40–55 minutes. Change only portfolio/p03/student/server/create-production-app.js. Keep both broken modes, API router, client source/build, tests and lockfile unchanged. Do not run build:client. The P03 fixture /notes/42 is a client route marker, not P01 seed note 42.

![Illustrative Network inspection diagram with four numbered callouts: correct local tab, request, response and wrong chatgpt.com tab to ignore.](assets/IMG-S09-04.svg)

Illustrative interface diagram. Inspect only the printed local origin and actual request/response. The chatgpt.com tab is an unrelated example to ignore. Document delivery and client boot remain separate witnesses.

### Step10.1

**WHERE YOU ARE** — The S09 form before a P03 run.

**WHAT TO FIND** — p03_prediction.

**EXACT ACTION** — Write two numbered predictions for static-only deep delivery and universal missing-asset/API contrast.

**WHAT YOU SHOULD SEE** — Each specifies exact mode, method/path/Accept, expected response class and falsifier before traces.

**WHAT TO RECORD** — Use separate case IDs and retain the actual pre-run predictions.

**DO NOT CONTINUE UNLESS** — Both predictions refer to the supplied modes and exact fixture.

**IF YOU DO NOT SEE THIS** — Read P03_PORTFOLIO/spec and identify the mode first; do not reuse a P01 note-existence assumption.

**STOP CONDITION** — A prediction is filled retrospectively or the fixture was rebuilt.

**CONTINUE WITH** — 10.2

Form locators: p03_prediction, p03_matrix.

### Step10.2

**WHERE YOU ARE** — The separately qualified terminal.

**WHAT TO FIND** — The student package root containing tools.

**EXACT ACTION** — Change directory to the student package root.

**WHAT YOU SHOULD SEE** — The root contains tools, projects, portfolio, capstone, guide and form.

**WHAT TO RECORD** — Record the exact root and later command.

**DO NOT CONTINUE UNLESS** — The new support observer is present and its explicit flag is understood.

**IF YOU DO NOT SEE THIS** — Locate the extracted root; do not run an archived observer or install Express to make it available.

**STOP CONDITION** — The support file is absent or dependencies are unqualified.

**CONTINUE WITH** — 10.3

Form locators: actual_environment, environment_limit.

```text
cd "D:\WTS09"
```

### Step10.3

**WHERE YOU ARE** — The qualified terminal at the student root.

**WHAT TO FIND** — The new explicit static-only loopback observer command.

**EXACT ACTION** — Run the static-only observer command once.

**WHAT YOU SHOULD SEE** — If dependencies are qualified, JSON records contain actual method/path/Accept/status/type/body SHA/log. Otherwise preserve the exact startup block.

**WHAT TO RECORD** — Store the actual stdout and locator in p03_static_only; no result is prefilled here.

**DO NOT CONTINUE UNLESS** — The observer binds only local loopback and the run is separately authorised.

**IF YOU DO NOT SEE THIS** — Record NOT_EXECUTED/BLOCKED and use source-only analysis if startup fails.

**STOP CONDITION** — An installation, remote URL or public server exposure would be required.

**CONTINUE WITH** — 10.4

Form locators: p03_static_only, p03_case_ledger, evidence_class.

```text
node tools/S09_OBSERVE_P03_LOOPBACK_v1_2_0.mjs --run-local static-only
```

### Step10.4

**WHERE YOU ARE** — The same root terminal after preserving the static-only output.

**WHAT TO FIND** — The new universal loopback observer command.

**EXACT ACTION** — Run the universal observer command once.

**WHAT YOU SHOULD SEE** — Actual affected missing-asset contrast and unaffected API control are recorded if the run succeeds.

**WHAT TO RECORD** — Record /assets/missing.js Accept HTML and /api/missing separately. The supplied completing API router is first; do not fabricate HTML for its miss.

**DO NOT CONTINUE UNLESS** — Output is preserved with exact mode/source identity.

**IF YOU DO NOT SEE THIS** — Keep the actual error or response even if it contradicts an earlier generic narrative.

**STOP CONDITION** — You reorder the preserved middleware or claim a result never emitted.

**CONTINUE WITH** — 10.5

Form locators: p03_universal, p03_api_control, p03_case_ledger.

```text
node tools/S09_OBSERVE_P03_LOOPBACK_v1_2_0.mjs --run-local universal
```

### Step10.5

**WHERE YOU ARE** — The same root terminal after your one-file P03 repair.

**WHAT TO FIND** — The new student loopback observer command.

**EXACT ACTION** — Run the student observer command once when qualified.

**WHAT YOU SHOULD SEE** — Actual repair rows can be compared against preserved broken modes and positive controls.

**WHAT TO RECORD** — Record full status/type/body identity/log order, one-file diff and remaining limitations. This is HTTP_LOOPBACK, not browser boot.

**DO NOT CONTINUE UNLESS** — Your repaired file is the only assessed edit and the supplied client build is exact.

**IF YOU DO NOT SEE THIS** — Preserve failures and continue only the named one-file repair; keep separate missing-index/post-header fixtures pending if unrun.

**STOP CONDITION** — You rebuild client-dist or substitute an abstract predicate model for actual HTTP.

**CONTINUE WITH** — 11.1

Form locators: p03_qualification, p03_diff, p03_middleware, p03_assets, p03_case_ledger.

```text
node tools/S09_OBSERVE_P03_LOOPBACK_v1_2_0.mjs --run-local student
```

## 11. Inspect the correct local browser tab and Network panel

Browser-menu routes below are illustrative label alternatives, not verified screenshots of a current browser release. Use the equivalent visible menu only when identifiable; otherwise STOP and ask. Chrome/Edge commonly use a three-dot menu; Firefox commonly uses a three-line menu. Do not label Firefox evidence as Chrome. P03 ordinary start is npm start from portfolio/p03/student in the qualified environment; use the address it prints and later Ctrl+C.

![Illustrative Network inspection diagram with four numbered callouts: correct local tab, request, response and wrong chatgpt.com tab to ignore.](assets/IMG-S09-04.svg)

Illustrative interface diagram. Inspect only the printed local origin and actual request/response. The chatgpt.com tab is an unrelated example to ignore. Document delivery and client boot remain separate witnesses.

### Step11.1

**WHERE YOU ARE** — The qualified terminal in portfolio/p03/student.

**WHAT TO FIND** — The start command and the preserved supplied client-dist.

**EXACT ACTION** — Run npm start without rebuilding the client.

**WHAT YOU SHOULD SEE** — The process prints Deep-link server listening at its actual local address, or its actual error.

**WHAT TO RECORD** — Record that exact address/port and command.

**DO NOT CONTINUE UNLESS** — Express/runtime/dependencies are already separately qualified.

**IF YOU DO NOT SEE THIS** — Record the exact error and keep browser/HTTP witnesses pending.

**STOP CONDITION** — A dependency install, client rebuild or remote binding would be needed.

**CONTINUE WITH** — 11.2

Form locators: actual_environment, p03_qualification, environment_limit.

```text
npm start
```

### Step11.2

**WHERE YOU ARE** — A dedicated browser tab for the running P03 server.

**WHAT TO FIND** — The printed origin and /notes/42.

**EXACT ACTION** — Navigate to the printed origin followed by /notes/42.

**WHAT YOU SHOULD SEE** — Record document response and actual visible client state separately. The supplied successful fixture marker is Note detail route: 42; do not infer it from HTTP alone.

**WHAT TO RECORD** — Record initial address, loaded assets and actual visible route in p03_qualification.

**DO NOT CONTINUE UNLESS** — This is the correct local P03 origin and a genuine browser observation.

**IF YOU DO NOT SEE THIS** — Return to the printed local URL; do not use Vite, a source HTML file or a remote page as production evidence.

**STOP CONDITION** — The tab is an unrelated domain/server or the app did not boot.

**CONTINUE WITH** — 11.3

Form locators: p03_qualification, evidence_class, evidence_index.

### Step11.3

**WHERE YOU ARE** — The dedicated local browser tab, browser selected in this guide.

**WHAT TO FIND** — Chrome/Edge three dots or Firefox three lines near the top-right window corner.

**EXACT ACTION** — Open the browser main menu.

**WHAT YOU SHOULD SEE** — The browser menu is visible for the current local tab.

**WHAT TO RECORD** — Record browser/version from your actual environment, not from a diagram.

**DO NOT CONTINUE UNLESS** — The menu belongs to your chosen browser.

**IF YOU DO NOT SEE THIS** — Use the qualified browser-menu alternatives shown by this guide; F12 is a keyboard fallback only if it opens tools on your platform.

**STOP CONDITION** — You cannot identify the menu or the tab.

**CONTINUE WITH** — 11.4

Form locators: actual_environment.

### Step11.4

**WHERE YOU ARE** — The browser main menu.

**WHAT TO FIND** — A visible More tools / Browser tools / Web Developer submenu, depending on browser/version.

**EXACT ACTION** — Open that visible tools submenu.

**WHAT YOU SHOULD SEE** — A developer-tools entry appears, or the interface differs.

**WHAT TO RECORD** — No real screenshot is supplied for this menu; record the label actually observed if useful.

**DO NOT CONTINUE UNLESS** — The submenu is identifiable without guessing a settings change.

**IF YOU DO NOT SEE THIS** — Use the permitted F12 fallback; if neither route is available, keep DevTools evidence pending.

**STOP CONDITION** — The route would require enabling a sandbox experiment or changing browser policy.

**CONTINUE WITH** — 11.5

Form locators: environment_limit.

### Step11.5

**WHERE YOU ARE** — The visible tools submenu.

**WHAT TO FIND** — Developer tools / Web Developer Tools / an equivalent explicit tools entry.

**EXACT ACTION** — Click the developer-tools entry.

**WHAT YOU SHOULD SEE** — A developer-tools panel opens docked or in another window.

**WHAT TO RECORD** — This opens an inspection interface; it does not itself record a request.

**DO NOT CONTINUE UNLESS** — The panel belongs to the local P03 tab.

**IF YOU DO NOT SEE THIS** — Locate the dedicated local tab again and repeat the permitted route.

**STOP CONDITION** — You cannot determine which page is being inspected.

**CONTINUE WITH** — 11.6

Form locators: environment_limit.

### Step11.6

**WHERE YOU ARE** — The developer-tools panel for the local P03 tab.

**WHAT TO FIND** — The Network tab; an overflow chevron may contain hidden panel tabs.

**EXACT ACTION** — Select Network.

**WHAT YOU SHOULD SEE** — A request-list area and its request-detail area are visible.

**WHAT TO RECORD** — Record only actual request data after a real navigation; a blank panel is not a trace.

**DO NOT CONTINUE UNLESS** — You can see the local origin and identify Network.

**IF YOU DO NOT SEE THIS** — Check panel-tab overflow or widen the panel; do not install tooling.

**STOP CONDITION** — You would substitute an illustrative diagram for an actual request capture.

**CONTINUE WITH** — 12.1

Form locators: p03_qualification, evidence_index.

For an actual direct-load request, keep Network open and reload the local page once. Select the document row, inspect Headers then Response. Record the observed method, path, request Accept, status, Content-Type and body identity. This later operation does not force an Accept value; the explicit observer matrix does.

## 12. Capture only relevant evidence and place it in the PDF

Every cited figure must be inside the single final PDF. The HTML form is text-only: a filename in a textbox does not insert a screenshot. Use the companion DOCX for genuine captures. These diagrams are labelled illustrative and cannot be passed off as your runtime screenshots.

![Illustrative evidence diagram showing an actual-evidence locator, mock account and token redaction labels and an image embedded in the same PDF.](assets/IMG-S09-05.svg)

Illustrative interface diagram. Account/token bars are mock redaction labels, not real private data or a runtime screenshot. Capture a safe real region and embed the actual image with its locator in the same PDF.

### Step12.1

**WHERE YOU ARE** — Your actual local app and request details before a capture.

**WHAT TO FIND** — Only the relevant route, response fields and visible client state.

**EXACT ACTION** — Arrange the window so unrelated accounts/private tabs are outside the capture region.

**WHAT YOU SHOULD SEE** — The relevant local address/data is readable without private account details.

**WHAT TO RECORD** — Plan a locator such as Figure1 — P01 Back witness; use actual numbering in your PDF.

**DO NOT CONTINUE UNLESS** — No credentials, tokens, private Moodle data or unrelated personal record is visible.

**IF YOU DO NOT SEE THIS** — Remove the irrelevant material from the view and recapture rather than covering it with a hidden Word object.

**STOP CONDITION** — A safe region cannot be captured without exposing private data.

**CONTINUE WITH** — 12.2

Form locators: privacy_check, evidence_index.

### Step12.2

**WHERE YOU ARE** — Your already available authorised screenshot tool.

**WHAT TO FIND** — The rectangular-region capture option; labels vary by platform/version.

**EXACT ACTION** — Capture the relevant region once.

**WHAT YOU SHOULD SEE** — A genuine image of your actual observation is available.

**WHAT TO RECORD** — Retain source/run identity and figure number with the capture.

**DO NOT CONTINUE UNLESS** — The capture is legible and corresponds to the observation claimed.

**IF YOU DO NOT SEE THIS** — Use the established OS screenshot route; if unavailable, record a text trace and its limitation.

**STOP CONDITION** — You would install a capture tool or fabricate a screenshot.

**CONTINUE WITH** — 12.3

Form locators: evidence_class, evidence_index.

### Step12.3

**WHERE YOU ARE** — The extracted form/FORM_S09_EN_GB.docx in an authorised document editor.

**WHAT TO FIND** — The evidence/capture position corresponding to your figure locator.

**EXACT ACTION** — Insert the actual capture at that position.

**WHAT YOU SHOULD SEE** — The image is visibly inside the editable document rather than merely named in text.

**WHAT TO RECORD** — Add figure number, actual source/date/class and a causal caption.

**DO NOT CONTINUE UNLESS** — The capture is your own observation and is embedded in the intended single PDF.

**IF YOU DO NOT SEE THIS** — Use the document editor existing Insert Picture or paste route; if blocked, retain the image and mark PDF evidence pending.

**STOP CONDITION** — You would claim an image is included because a filename is typed.

**CONTINUE WITH** — 12.4

Form locators: evidence_index, privacy_check.

### Step12.4

**WHERE YOU ARE** — The document with the actual inserted figure.

**WHAT TO FIND** — The caption and the figure itself.

**EXACT ACTION** — Write one sentence linking the visible result to the mechanism and its limitation.

**WHAT YOU SHOULD SEE** — The figure has a readable locator/caption and explains what it supports.

**WHAT TO RECORD** — For example distinguish observed Back state from a source-only call-count inference.

**DO NOT CONTINUE UNLESS** — The caption does not claim a larger witness class than the image/trace provides.

**IF YOU DO NOT SEE THIS** — Narrow the claim or add the missing actual trace; keep unresolved parts pending.

**STOP CONDITION** — A screenshot of a green test or HTML200 is treated as universal correctness.

**CONTINUE WITH** — 13.1

Form locators: mechanism_explanation, reflection_limit, evidence_index.

## 13. Open a new Gemini Web chat and send one bounded prompt

This is a later genuine student interaction, not a conversation manufactured by the package. Use Gemini Web, not CLI/SDK/API keys. Choose one claim from your own route/history or delivery trace. If the service, account or permitted interaction is unavailable, record PENDING and use no automatic invented substitute. A prior teacher-approved alternative needs a real recorded reference.

![Illustrative diagram showing one minimal sanitised prompt, one claim and an independent evidence check.](assets/IMG-S09-06.svg)

Illustrative interface diagram. No actual exchange means PENDING. A second model paraphrase is not an experiment.

### Step13.1

**WHERE YOU ARE** — Your browser with the local guide kept open.

**WHAT TO FIND** — The New tab plus button beside existing tabs.

**EXACT ACTION** — Open one new browser tab.

**WHAT YOU SHOULD SEE** — A fresh tab appears and the local guide remains available.

**WHAT TO RECORD** — The AI interaction has not happened yet; gemini_mode can remain PENDING.

**DO NOT CONTINUE UNLESS** — You are using the permitted web route.

**IF YOU DO NOT SEE THIS** — Use the browser menu New tab alternative if the plus button is hidden.

**STOP CONDITION** — A prohibited plugin, CLI or API route would be needed.

**CONTINUE WITH** — 13.2

Form locators: gemini_mode.

### Step13.2

**WHERE YOU ARE** — The new browser tab address bar.

**WHAT TO FIND** — The public Gemini Web address.

**EXACT ACTION** — Navigate to https://gemini.google.com.

**WHAT YOU SHOULD SEE** — The service page loads, asks for your already permitted account route or reports a real availability block.

**WHAT TO RECORD** — Record the actual interaction status without including account identifiers in your evidence.

**DO NOT CONTINUE UNLESS** — You have an authorised personal/institutional service route.

**IF YOU DO NOT SEE THIS** — Keep PENDING and record the actual block; do not create or share credentials through this form.

**STOP CONDITION** — Access is unavailable or would require an unapproved account action.

**CONTINUE WITH** — 13.3

Form locators: gemini_mode, environment_limit.

### Step13.3

**WHERE YOU ARE** — Gemini Web after any permitted existing account access.

**WHAT TO FIND** — New chat / an equivalent visible fresh-chat control; placement may vary.

**EXACT ACTION** — Open a new chat using the visible control.

**WHAT YOU SHOULD SEE** — A fresh prompt area appears without unrelated conversation content.

**WHAT TO RECORD** — Keep a bounded actual prompt/answer excerpt only.

**DO NOT CONTINUE UNLESS** — You can distinguish this new chat from a private prior conversation.

**IF YOU DO NOT SEE THIS** — Record PENDING if a fresh chat cannot be identified; do not paste an entire old conversation.

**STOP CONDITION** — A private full conversation would be sent as context.

**CONTINUE WITH** — 13.4

Form locators: gemini_mode.

### Step13.4

**WHERE YOU ARE** — This guide prompt box before using Gemini.

**WHAT TO FIND** — The bounded prompt with its bracketed placeholders.

**EXACT ACTION** — Copy the bounded prompt with Copy or the visible manual-copy fallback.

**WHAT YOU SHOULD SEE** — The prompt is available to paste, or the manual text is selected.

**WHAT TO RECORD** — Replace each placeholder with one own claim and a minimal sanitised excerpt before sending.

**DO NOT CONTINUE UNLESS** — No placeholder is interpreted as a fabricated actual response.

**IF YOU DO NOT SEE THIS** — Select the visible prompt text and use the normal copy command if file:// clipboard access fails.

**STOP CONDITION** — The prompt asks for a whole completed assessed implementation.

**CONTINUE WITH** — 13.5

Form locators: gemini_prompt.

### Step13.5

**WHERE YOU ARE** — The new Gemini Web prompt area before sending.

**WHAT TO FIND** — Your edited minimal prompt and excerpt.

**EXACT ACTION** — Paste the sanitised prompt into the prompt area.

**WHAT YOU SHOULD SEE** — The visible text contains one claim, your pre-check prediction and a small excerpt.

**WHAT TO RECORD** — Record the exact submitted text in gemini_prompt after privacy review.

**DO NOT CONTINUE UNLESS** — No credentials/tokens/cookies/private code/Moodle records/complete conversation are present.

**IF YOU DO NOT SEE THIS** — Remove the unnecessary content before submission; when uncertain, keep PENDING and ask for the allowed minimal scope.

**STOP CONDITION** — Private or institutional data would be transmitted.

**CONTINUE WITH** — 13.6

Form locators: gemini_prompt, privacy_check.

### Step13.6

**WHERE YOU ARE** — Gemini Web with the reviewed bounded prompt.

**WHAT TO FIND** — The visible Send button.

**EXACT ACTION** — Send the prompt once.

**WHAT YOU SHOULD SEE** — The service produces a response or shows an actual error; wait until the response is complete before extracting a claim.

**WHAT TO RECORD** — Keep only the relevant genuine answer excerpt in gemini_claim; record a service error honestly.

**DO NOT CONTINUE UNLESS** — The excerpt really came from this interaction and is not a package example.

**IF YOU DO NOT SEE THIS** — If no complete response appears, record PENDING/error rather than fabricating it.

**STOP CONDITION** — You would represent a sample or synthetic teacher claim as a real model response.

**CONTINUE WITH** — 14.1

Form locators: gemini_claim, gemini_mode, record_status_ledger.

### Bounded prompt

```text
I am checking one claim in my own S09 work.
Claim: [one claim about URL/history or document delivery]
Source/trace excerpt: [minimal sanitised excerpt]
Prediction before checking: [my prediction]
Identify one assumption and one counterexample or independent check.
Do not implement the project or claim that you ran my code.
Distinguish a source inference, a model and an actual runtime observation.
```

## 14. Check one claim independently and write a qualified verdict

Separate OBSERVED, INFERRED and UNKNOWN. Gemini is a reviewer/explainer, not the authority that certifies your code. A second model paraphrase is not an independent observation. The public exercise offers a challenged claim without a completed assessed solution or a teacher answer key.

![Illustrative diagram showing one minimal sanitised prompt, one claim and an independent evidence check.](assets/IMG-S09-06.svg)

Illustrative interface diagram. No actual exchange means PENDING. A second model paraphrase is not an experiment.

### Step14.1

**WHERE YOU ARE** — Your relevant actual Gemini response excerpt.

**WHAT TO FIND** — One specific falsifiable claim.

**EXACT ACTION** — Select that single claim for checking.

**WHAT YOU SHOULD SEE** — The chosen claim has a bounded subject and evidence requirement.

**WHAT TO RECORD** — Copy the relevant excerpt and classify its assertion as OBSERVED/INFERRED/UNKNOWN in your own explanation.

**DO NOT CONTINUE UNLESS** — The claim is from the actual excerpt, not a made-up dialogue.

**IF YOU DO NOT SEE THIS** — Narrow a broad statement to one route/history or delivery assertion.

**STOP CONDITION** — There is no actual exchange but the record would label one genuine.

**CONTINUE WITH** — 14.2

Form locators: gemini_claim, counterexample_record.

### Step14.2

**WHERE YOU ARE** — The form independent_check field beside your own source/test/trace evidence.

**WHAT TO FIND** — The exact contract clause, named test, diff or actual trace that can check the claim.

**EXACT ACTION** — Compare the claim against that independent evidence.

**WHAT YOU SHOULD SEE** — A supporting, contradicting or incomplete witness is identifiable with its class/locator.

**WHAT TO RECORD** — Record method, result and source/run identity. A source inference can challenge a source claim but does not become runtime proof.

**DO NOT CONTINUE UNLESS** — The evidence is independent of a model paraphrase.

**IF YOU DO NOT SEE THIS** — Record UNKNOWN and the missing witness if no valid check is available.

**STOP CONDITION** — You would ask the same model for assurance and call it an experiment.

**CONTINUE WITH** — 14.3

Form locators: independent_check, evidence_class, evidence_index.

### Step14.3

**WHERE YOU ARE** — The S09 form Gemini verdict control.

**WHAT TO FIND** — ACCEPTED, REJECTED, PARTIALLY_ACCEPTED or UNKNOWN.

**EXACT ACTION** — Select the verdict justified by your independent evidence.

**WHAT YOU SHOULD SEE** — The selected verdict describes the bounded claim, not completion of P01/P03.

**WHAT TO RECORD** — Explain the correction and explicit limitation in correction_limit.

**DO NOT CONTINUE UNLESS** — The reason and locator support the verdict.

**IF YOU DO NOT SEE THIS** — Use UNKNOWN when the required witness is missing; list unfinished implementation separately.

**STOP CONDITION** — A favourable AI verdict would replace required technical work.

**CONTINUE WITH** — 14.4

Form locators: gemini_verdict, correction_limit, pending_work.

### Step14.4

**WHERE YOU ARE** — The form transfer/reflection fields.

**WHAT TO FIND** — economic_informatics_transfer and mechanism_explanation.

**EXACT ACTION** — Write one causal transfer paragraph from your own witness.

**WHAT YOU SHOULD SEE** — The paragraph names a record identity, unsaved proposal, confirmed-state scope and delivery limitation.

**WHAT TO RECORD** — Explain how stale identity or a false successful response could mislead an order/invoice review; do not claim financial or security certification.

**DO NOT CONTINUE UNLESS** — The paragraph connects cause, observable result, economic implication and limitation.

**IF YOU DO NOT SEE THIS** — Use the four-owner table in this guide to identify the missing causal link.

**STOP CONDITION** — A generic reflection or URL alone is claimed to prove a saved business transaction.

**CONTINUE WITH** — 15.1

Form locators: economic_informatics_transfer, mechanism_explanation, learning_transfer.

## 15. Export and re-import an unverified JSON draft

The successor form retains 43 original identifiers and 11 explicitly new identifiers. Imported text is an unverified draft, not a re-executed experiment. Autosave is optional and may fail under file://. Export a portable JSON copy before replacing fields. Old v1.1.0 drafts use the separate migration control rather than being silently accepted as v1.2.1.

### Step15.1

**WHERE YOU ARE** — The local S09 form after entering your current draft.

**WHAT TO FIND** — Check core draft.

**EXACT ACTION** — Click Check core draft.

**WHAT YOU SHOULD SEE** — Structural issues are shown while your text remains; no technical result is certified.

**WHAT TO RECORD** — Record missing content in pending_work and truthful case statuses.

**DO NOT CONTINUE UNLESS** — You understand that field completeness does not verify observations or award a mark.

**IF YOU DO NOT SEE THIS** — Correct only real omissions; keep blocked/unexecuted results honest.

**STOP CONDITION** — You would replace a failure with PASS just to silence a structural message.

**CONTINUE WITH** — 15.2

Form locators: pending_work, record_status_ledger.

### Step15.2

**WHERE YOU ARE** — The form with your current draft preserved.

**WHAT TO FIND** — Export JSON draft.

**EXACT ACTION** — Click Export JSON draft.

**WHAT YOU SHOULD SEE** — The browser requests a .json download or reports its actual error.

**WHAT TO RECORD** — Confirm the draft file actually appears in Downloads and keep its identity.

**DO NOT CONTINUE UNLESS** — The file exists; a button click alone is not a saved backup.

**IF YOU DO NOT SEE THIS** — Use the actual browser download route; preserve current text if export failed.

**STOP CONDITION** — You would clear/import over current text without a backup.

**CONTINUE WITH** — 15.3

Form locators: record_status_ledger.

### Step15.3

**WHERE YOU ARE** — The form after retaining a portable draft backup.

**WHAT TO FIND** — Import JSON draft.

**EXACT ACTION** — Choose the saved v1.2.1 JSON draft using Import JSON draft.

**WHAT YOU SHOULD SEE** — The strict import is accepted or rejected with a visible reason; accepted values remain unverified.

**WHAT TO RECORD** — Review every field and renew privacy/declaration later. An import must reset declarations/review state.

**DO NOT CONTINUE UNLESS** — You are intentionally replacing current fields with the identified draft.

**IF YOU DO NOT SEE THIS** — Use Migrate v1.1.0 draft only for an actual old-schema file; preserve rejected file/error and do not hand-edit the schema to bypass validation.

**STOP CONDITION** — Import would overwrite newer unsaved work or execute imported markup.

**CONTINUE WITH** — 15.4

Form locators: declaration, pdf_status, privacy_check, record_status_ledger.

### Step15.4

**WHERE YOU ARE** — The form optional local-storage controls.

**WHAT TO FIND** — Optional local autosave, currently off.

**EXACT ACTION** — Enable Optional local autosave only if you choose local browser storage.

**WHAT YOU SHOULD SEE** — The form shows stored status or an explicit storage error.

**WHAT TO RECORD** — Keep JSON as the portable backup; local storage is not Moodle or durable acceptance.

**DO NOT CONTINUE UNLESS** — A visible success message reflects an actual save, or the error is retained.

**IF YOU DO NOT SEE THIS** — If storage fails, disable autosave and keep/export JSON; do not assume hidden saving succeeded.

**STOP CONDITION** — A failed local save is reported as saved, or clearing is claimed to erase exports/backups.

**CONTINUE WITH** — 16.1

Form locators: record_status_ledger, reflection_limit.

Restore browser draft is an explicit replacement action. Clear form and browser draft requires a real confirmation and does not erase exported JSON/PDF files or all browser backups.

## 16. Export the first PDF after truthful preconditions

Your final submission is one individual PDF named TW2026_S09_GROUP_Surname_Firstname.pdf. P01 and required P03 evidence belong in the same PDF. P02 is conceptual transfer plus true semester status; NOT_STARTED is allowed. No extra C09 Assignment, separate P03 upload or invented deadline exists. A complete record may honestly report blocked or failed work; it does not establish technical completion or a mark.

![Illustrative submission diagram separating first PDF export, reopening every page and the later actual Moodle submission status.](assets/IMG-S09-07.svg)

Illustrative interface diagram. The first PDF never depends on a future review or fictional Moodle receipt.

### Step16.1

**WHERE YOU ARE** — The S09 form before first PDF export.

**WHAT TO FIND** — Review record fields.

**EXACT ACTION** — Click Review record fields.

**WHAT YOU SHOULD SEE** — A structural message identifies missing record fields or RECORD_FIELDS_COMPLETE_NOT_TECHNICALLY_QUALIFIED.

**WHAT TO RECORD** — Retain failures, evidence class, pending remediation and limitations; never turn a review status into technical PASS.

**DO NOT CONTINUE UNLESS** — You have accounted for required cases truthfully rather than merely typing success markers.

**IF YOU DO NOT SEE THIS** — Correct an omission or keep a clearly labelled truthful draft; do not invent an actual trace.

**STOP CONDITION** — The record contains synthetic evidence labelled as an actual student run.

**CONTINUE WITH** — 16.2

Form locators: record_status_ledger, pending_work, reflection_limit.

### Step16.2

**WHERE YOU ARE** — The form pre_export_checklist field.

**WHAT TO FIND** — The first-export checklist and identity-derived filename.

**EXACT ACTION** — Complete the truthful first-export checklist.

**WHAT YOU SHOULD SEE** — Identity/name, readable locators/captions, privacy and record status are accounted for.

**WHAT TO RECORD** — Do not assert that this first PDF is already saved/reopened or submitted.

**DO NOT CONTINUE UNLESS** — All cited captures are actually inside the selected DOCX/PDF route; HTML text-only locators alone are insufficient.

**IF YOU DO NOT SEE THIS** — Use the DOCX route to insert real captures or label missing capture evidence pending.

**STOP CONDITION** — The checklist requires a future PDF review or Moodle receipt as a prerequisite to first export.

**CONTINUE WITH** — 16.2a

Form locators: pre_export_checklist, evidence_index, pdf_status.

### Step16.2a

**WHERE YOU ARE** — The form after removing unnecessary private material.

**WHAT TO FIND** — The Privacy review checkbox [privacy_check].

**EXACT ACTION** — Confirm Privacy review first.

**WHAT YOU SHOULD SEE** — Privacy review is checked and any prior declaration has been reset by this content change.

**WHAT TO RECORD** — Keep the privacy confirmation truthful; an imported or earlier declaration is not reused.

**DO NOT CONTINUE UNLESS** — No private credential/account/institutional data is included and the content has been reviewed.

**IF YOU DO NOT SEE THIS** — Remove the material and repeat the review before declaring accuracy.

**STOP CONDITION** — Private data remains or the checkbox would falsely attest review.

**CONTINUE WITH** — 16.3

Form locators: privacy_check, declaration.

### Step16.3

**WHERE YOU ARE** — The form with Privacy review already checked.

**WHAT TO FIND** — The individual declaration checkbox [declaration].

**EXACT ACTION** — Confirm the personal accuracy declaration last.

**WHAT YOU SHOULD SEE** — The declaration reflects the current reviewed work and prior privacy confirmation, not an automatic prefilled approval.

**WHAT TO RECORD** — Do not change privacy or other content after this declaration without renewing it; relevant edits/imports reset the declaration.

**DO NOT CONTINUE UNLESS** — Privacy review is already checked and you personally stand behind the truthful statuses and scope limits.

**IF YOU DO NOT SEE THIS** — Leave declaration false until inaccurate content is corrected, then confirm privacy first and declaration last.

**STOP CONDITION** — The record attributes another person’s work, an invented run or fake conversation to you.

**CONTINUE WITH** — 16.4

Form locators: declaration, privacy_check.

### Step16.4

**WHERE YOU ARE** — The form ready for the first candidate export.

**WHAT TO FIND** — Print first PDF candidate.

**EXACT ACTION** — Click Print first PDF candidate.

**WHAT YOU SHOULD SEE** — The browser print window appears, or a visible error retains the draft.

**WHAT TO RECORD** — The snapshot may honestly say FIRST_EXPORT_CANDIDATE_NOT_YET_REVIEWED; this is not a Moodle receipt.

**DO NOT CONTINUE UNLESS** — Pre-export conditions are truthful and no existing-PDF proof is demanded.

**IF YOU DO NOT SEE THIS** — Use Print truthful draft when the intended route is still a draft; a native DOCX route follows its manual equivalent checklist.

**STOP CONDITION** — An export control claims that the file already exists or is finally submitted.

**CONTINUE WITH** — 16.5

Form locators: pdf_status, pre_export_checklist.

### Step16.5

**WHERE YOU ARE** — The browser or document-editor PDF destination window.

**WHAT TO FIND** — Save as PDF / an equivalent available PDF destination.

**EXACT ACTION** — Select the available PDF destination.

**WHAT YOU SHOULD SEE** — A save-file route appears or the actual tool shows a block.

**WHAT TO RECORD** — Record the actual export application; browser/Word acceptance is separate from local authoring.

**DO NOT CONTINUE UNLESS** — You can choose a local file destination without uploading to an external service.

**IF YOU DO NOT SEE THIS** — Use the already available authorised PDF export route; otherwise preserve the draft and mark export pending.

**STOP CONDITION** — A new installation or external conversion service is needed.

**CONTINUE WITH** — 17.1

Form locators: actual_environment, pdf_status, environment_limit.

## 17. Save, reopen and inspect every PDF page

Post-export review happens after the first saved snapshot. Keep that review in a separate personal/local record; do not make the first PDF depend on a future review of itself. If defects require content changes, renew the declaration, save a corrected successor and inspect again. Native Word/browser/platform acceptance is not implied by package authoring.

![Illustrative submission diagram separating first PDF export, reopening every page and the later actual Moodle submission status.](assets/IMG-S09-07.svg)

Illustrative interface diagram. The first PDF never depends on a future review or fictional Moodle receipt.

### Step17.1

**WHERE YOU ARE** — The actual PDF save-file dialog.

**WHAT TO FIND** — The filename box and D:\#___MY_SPACE\Downloads, or your actual chosen local folder.

**EXACT ACTION** — Save with TW2026_S09_GROUP_Surname_Firstname.pdf using your real group/name components.

**WHAT YOU SHOULD SEE** — The PDF file is written, or an actual save error occurs.

**WHAT TO RECORD** — Keep the actual filename and location; do not invent a file from the print request.

**DO NOT CONTINUE UNLESS** — The file appears at the selected location and has .pdf extension.

**IF YOU DO NOT SEE THIS** — Locate the browser Downloads or selected folder; preserve the draft if saving failed.

**STOP CONDITION** — No file exists or an unrelated PDF would be submitted.

**CONTINUE WITH** — 17.2

Form locators: pdf_status, record_status_ledger.

### Step17.2

**WHERE YOU ARE** — File Explorer at the saved PDF.

**WHAT TO FIND** — The exact saved S09 PDF filename.

**EXACT ACTION** — Open that exact PDF.

**WHAT YOU SHOULD SEE** — A PDF viewer displays the saved document.

**WHAT TO RECORD** — Record actual file identity/review outside the already-saved snapshot.

**DO NOT CONTINUE UNLESS** — This is the saved PDF, not a print-preview window or DOCX.

**IF YOU DO NOT SEE THIS** — Return to the saved folder and select the identified file.

**STOP CONDITION** — You cannot identify the actual exported file.

**CONTINUE WITH** — 17.3

### Step17.3

**WHERE YOU ARE** — The saved PDF viewer.

**WHAT TO FIND** — Every page, its text, figures, captions and evidence locators.

**EXACT ACTION** — Inspect each page from first to last.

**WHAT YOU SHOULD SEE** — Text is readable/unclipped; actual captures and referenced figures are present; identities/version/status agree.

**WHAT TO RECORD** — Record the actual review outcome in your separate personal post-export note.

**DO NOT CONTINUE UNLESS** — All pages have actually been inspected.

**IF YOU DO NOT SEE THIS** — Correct the source document/form, renew the declaration, save a successor and inspect it again.

**STOP CONDITION** — Text/captures are missing, a locator is unresolved or private material is visible.

**CONTINUE WITH** — 18.1

The later review note is not a required field inside the first PDF. Do not re-export solely to manufacture a later receipt in the earlier snapshot.

## 18. Submit one PDF and record the actual private Moodle status

This is later student submission guidance for the actual assigned activity. No Moodle UI was inspected or configured during package production. Labels below are illustrative alternatives and may differ at online.ase.ro. The teacher supplies actual course/activity title, deadline and file-size rules; do not guess these values or upload to a similarly named course.

![Illustrative submission diagram separating first PDF export, reopening every page and the later actual Moodle submission status.](assets/IMG-S09-07.svg)

Illustrative interface diagram. The first PDF never depends on a future review or fictional Moodle receipt.

### Step18.1

**WHERE YOU ARE** — Your browser after the actual PDF review.

**WHAT TO FIND** — The institutional address https://online.ase.ro.

**EXACT ACTION** — Open the institution’s Moodle address in a new tab.

**WHAT YOU SHOULD SEE** — The actual institutional site loads or shows an availability block.

**WHAT TO RECORD** — Keep personal login/account data out of the guide/form/captures.

**DO NOT CONTINUE UNLESS** — You have the established authorised institutional account route.

**IF YOU DO NOT SEE THIS** — Use the institution’s usual sign-in support; keep the PDF and record a block if unavailable.

**STOP CONDITION** — Access would require sharing credentials or guessing an account.

**CONTINUE WITH** — 18.2

### Step18.2

**WHERE YOU ARE** — Your signed-in institutional Moodle course list.

**WHAT TO FIND** — The actual course specified by your teacher.

**EXACT ACTION** — Open that exact course.

**WHAT YOU SHOULD SEE** — The course header/title agrees with the teacher’s actual instruction.

**WHAT TO RECORD** — Check the course identity privately; no screenshot with unnecessary account data enters the PDF.

**DO NOT CONTINUE UNLESS** — You can confirm the actual course.

**IF YOU DO NOT SEE THIS** — Return to the course list and use the teacher’s exact title/link.

**STOP CONDITION** — There are ambiguous similarly named courses.

**CONTINUE WITH** — 18.3

### Step18.3

**WHERE YOU ARE** — The verified course page.

**WHAT TO FIND** — The actual Week09 / S09 assignment supplied by your teacher.

**EXACT ACTION** — Open that exact assignment.

**WHAT YOU SHOULD SEE** — Its title, deadline, accepted type and size limit are visible if configured.

**WHAT TO RECORD** — Inspect the actual rules; no date/size was invented by this package.

**DO NOT CONTINUE UNLESS** — The assignment is S09 and accepts the intended individual PDF.

**IF YOU DO NOT SEE THIS** — Ask the teacher for the correct activity when the title/rules cannot be established.

**STOP CONDITION** — The activity is C09, another seminar or a different submission.

**CONTINUE WITH** — 18.4

### Step18.4

**WHERE YOU ARE** — The verified actual S09 assignment page.

**WHAT TO FIND** — Add submission / Edit submission / an equivalent visible file-submission control.

**EXACT ACTION** — Open the file-submission control.

**WHAT YOU SHOULD SEE** — An upload area or file-picker route appears.

**WHAT TO RECORD** — No submission has happened merely because an upload window opened.

**DO NOT CONTINUE UNLESS** — The visible route belongs to the verified S09 activity.

**IF YOU DO NOT SEE THIS** — Use the equivalent existing control only when identifiable; otherwise retain the PDF and ask.

**STOP CONDITION** — A label mismatch would require guessing or uploading elsewhere.

**CONTINUE WITH** — 18.5

### Step18.5

**WHERE YOU ARE** — The actual assignment upload area.

**WHAT TO FIND** — Your reviewed TW2026_S09_GROUP_Surname_Firstname.pdf.

**EXACT ACTION** — Select that exact PDF using the file picker or drop it into the identified upload area.

**WHAT YOU SHOULD SEE** — The upload progress completes and the correct filename appears.

**WHAT TO RECORD** — Confirm filename/type/size against the actual activity rules.

**DO NOT CONTINUE UNLESS** — The transfer is complete and only the intended individual PDF is attached.

**IF YOU DO NOT SEE THIS** — Wait for an actual completed transfer; preserve the local PDF if an error occurs.

**STOP CONDITION** — A wrong/private ZIP, teacher key or unrelated PDF is attached.

**CONTINUE WITH** — 18.6

### Step18.6

**WHERE YOU ARE** — The upload area with the verified filename shown.

**WHAT TO FIND** — Save changes / an equivalent actual save control.

**EXACT ACTION** — Activate the actual save control.

**WHAT YOU SHOULD SEE** — The activity shows a saved draft or another actual status.

**WHAT TO RECORD** — A saved draft is not automatically final submission.

**DO NOT CONTINUE UNLESS** — The observed filename is correct and the save operation completed.

**IF YOU DO NOT SEE THIS** — Record a real error and keep the local PDF; do not assert submission from the button click.

**STOP CONDITION** — The save is incomplete or the filename changed.

**CONTINUE WITH** — 18.7

### Step18.7

**WHERE YOU ARE** — The actual assignment after saving.

**WHAT TO FIND** — Submit assignment / final-submit confirmation, when present.

**EXACT ACTION** — Activate the visible final-submit control if the activity provides it.

**WHAT YOU SHOULD SEE** — A confirmation or submission statement may appear, or the configured workflow may already show final status.

**WHAT TO RECORD** — Use only the actual workflow; some Moodle activities differ.

**DO NOT CONTINUE UNLESS** — You can identify whether a final-submit step is required.

**IF YOU DO NOT SEE THIS** — If no control is present, inspect the actual status instead of inventing a button.

**STOP CONDITION** — Status remains Draft and no final route can be established.

**CONTINUE WITH** — 18.8

### Step18.8

**WHERE YOU ARE** — The actual final-submit confirmation, if shown.

**WHAT TO FIND** — The actual confirmation/statement control.

**EXACT ACTION** — Confirm the final submission using that visible control.

**WHAT YOU SHOULD SEE** — The activity returns a final status or an actual error.

**WHAT TO RECORD** — Do not copy a receipt into a pre-upload PDF; retain the real result privately.

**DO NOT CONTINUE UNLESS** — You have read the statement and the file is the intended reviewed PDF.

**IF YOU DO NOT SEE THIS** — If an error occurs, retain the actual message and follow the teacher’s established support route.

**STOP CONDITION** — The confirmation would attest to inaccurate authorship or private data.

**CONTINUE WITH** — 18.9

### Step18.9

**WHERE YOU ARE** — The actual assignment status page after the configured workflow.

**WHAT TO FIND** — The final status, filename and timestamp.

**EXACT ACTION** — Read and record those actual values in a separate private post-submission note.

**WHAT YOU SHOULD SEE** — You can distinguish Submitted / Submitted for grading / another real final label from Draft.

**WHAT TO RECORD** — Keep the actual course/activity/status/file/time privately outside the final PDF. No mandatory re-export is needed for a later receipt.

**DO NOT CONTINUE UNLESS** — The actual status is final under the activity’s configuration.

**IF YOU DO NOT SEE THIS** — If it remains Draft, STOP and complete the available final step or ask the teacher; retain the local PDF.

**STOP CONDITION** — An upload/save click is represented as final without inspecting the actual status.

**CONTINUE WITH** — 19.1

## 19. Stop the local process and preserve truthful evidence

At content minute 60, stop the teaching route and save a truthful exit ticket. P01/P03 complete work continues before the real teacher-set deadline; the reserved 30 minutes are not content overflow. P02 full integration is a separate semester milestone. Preserve originals and your actual evidence; do not delete earlier deliveries, publish the package or restart suspended R3B-6 work.

### Step19.1

**WHERE YOU ARE** — The terminal that actually hosts your P01 or P03 process.

**WHAT TO FIND** — The process terminal, not another unrelated terminal.

**EXACT ACTION** — Press Ctrl+C once to stop that local process.

**WHAT YOU SHOULD SEE** — The terminal returns to a prompt or reports its actual stop outcome.

**WHAT TO RECORD** — Record an unclosed process honestly; do not invent start/stop events for a process never run.

**DO NOT CONTINUE UNLESS** — You identified the correct process terminal.

**IF YOU DO NOT SEE THIS** — Locate the terminal whose command/printed URL matches your run; ask if the process cannot be identified.

**STOP CONDITION** — You would kill an unrelated process or modify a remote service.

**CONTINUE WITH** — 19.2

Form locators: actual_environment, record_status_ledger.

### Step19.2

**WHERE YOU ARE** — The form exit_ticket and pending_work fields at content STOP.

**WHAT TO FIND** — One URL-owned value, one draft-owned state, one unproved result and the next required action.

**EXACT ACTION** — Write the truthful exit ticket.

**WHAT YOU SHOULD SEE** — The core content route ends with explicit unfinished work rather than forced success.

**WHAT TO RECORD** — Separate REQUIRED P01/P03/Gemini from CAPSTONE P02 status. NOT_STARTED is honest for the separate capstone.

**DO NOT CONTINUE UNLESS** — Content has stopped at minute 60 and outstanding obligations remain visible.

**IF YOU DO NOT SEE THIS** — Save the current draft and list the actual next step rather than adding overflow content.

**STOP CONDITION** — A timer/progress checkbox is treated as evidence of completed experiments.

**CONTINUE WITH** — 19.3

Form locators: exit_ticket, pending_work, p02_integration_status, reflection_limit.

### Step19.3

**WHERE YOU ARE** — Your local evidence folder and exported draft/PDF files.

**WHAT TO FIND** — The original student ZIP and actual evidence copies.

**EXACT ACTION** — Keep them together without overwriting the originals.

**WHAT YOU SHOULD SEE** — Original package, draft and actual traces/captures remain identifiable.

**WHAT TO RECORD** — Retain exact version/source/run locators. The private teacher package is never a student upload.

**DO NOT CONTINUE UNLESS** — You can reproduce which source and observation each claim uses.

**IF YOU DO NOT SEE THIS** — Use a new filename/folder for a corrected successor and record its relation to the previous draft.

**STOP CONDITION** — A prior source is deleted, a model is renamed actual or an upload/publication is improvised.

**CONTINUE WITH** — Finish this guide; continue required work only within its later authorised scope.

Form locators: package_identity, evidence_index, record_status_ledger.

Your teacher determines the actual deadline. There is no extra P02 implementation deduction in the S09 rubric and no separate P03 PDF. A recorded field-complete status is not a mark or platform acceptance.

## Source-bound case coverage

These expected behaviours are from the contract, not actual results recorded by package production. Each actual observation retains input/action/expected/observed/difference/locator/mechanism/class/limit.

**P01-ROOT (happy)** — explicit stack ['/unknown', '/'] with index1; Initialise at /. Expected contract: /notes rendered; root transition replaces the root entry; Back exposes /unknown without an intervening root entry. Witness: Named root-replacement history witness plus exact resulting route; model and real browser distinguished.

**P01-DIRECT (happy)** — Fresh supplied store: note1 URL state; note2 Controlled forms; Direct initialisation /notes/1 then independent /notes/2/edit. Expected contract: Exact addressed note title/body; edit values belong to note2. Witness: Initial URL, noteId and visible title/body; fixture/store lifetime and witness class.

**P01-CREATE (happy)** — Fresh seed1/2; history ['/notes', '/notes/new']; index1; Submit title "  Budget note  " and body "  Revised estimate  "; Back then Forward. Expected contract: One create with trimmed strings; deterministic new ID3 in fresh store; /notes/3 replaces form; Back /notes then Forward /notes/3. Witness: Before-run prediction, store call, returned ID, detail content, explicit stack, actual Back/Forward.

**P01-EDIT (happy)** — Seed note2; history ['/notes', '/notes/2', '/notes/2/edit']; index2; Submit trimmed update then Back/Forward. Expected contract: One update of addressed2; route /notes/2; prior edit URL replaced; Back earlier /notes/2 then Forward revised /notes/2. Witness: Store-call target and inputs, pre/post route/state, history index and content, absence of edit form on Back.

**P01-BLANK (rejected)** — /notes/new or existing edit route; before-store snapshot; Submit whitespace-only title. Expected contract: Accessible validation error; zero create/update; no navigation; draft retained. Witness: Error accessible name/text, call count or source-qualified no-call witness, unchanged address and store.

**P01-CANCEL (edge)** — /notes/new and separately /notes/2/edit; unsaved draft and before-store snapshot; Activate declarative Cancel link. Expected contract: New→/notes; edit→/notes/2; no mutation. Witness: Destination, before/after store and no-call observation.

**P01-TARGET-CHANGE (edge)** — /notes/1/edit with modified unsaved draft; Navigate within the same running router to /notes/2/edit. Expected contract: Fields initialise from note2; no stale note1 draft or write. Witness: URL noteId1→2, exact titles/bodies, supplied store values and draft distinction.

**P01-MISSING (edge)** — Fresh seed1/2; no99; Direct initialise /notes/99 and separately /notes/99/edit. Expected contract: Stable same note-not-found state; edit does not show another record/form. Witness: Initial path, missing get99, visible state, absence of unintended form/crash.

**P01-UNKNOWN (edge)** — /unknown in already booted client or MemoryRouter; Resolve unknown route. Expected contract: Page-not-found client view distinct from missing note. Witness: Exact path and client view; do not call it an HTTP404 without an HTTP observation.

**P01-PUSH-COUNTEREXAMPLE (student_counterexample_design)** — Your own recorded URL/history claim and before-run prediction, with a precisely stated fixture/history.; Design an independent falsifier of the claim that a correct final detail URL proves the required history policy.. Expected contract: Your design distinguishes destination evidence from history evidence. No result is prefilled; the complete private teacher witness/key is not included.. Witness: Record your own falsifier, actual or pending evidence class/locator and explicit limitation. observed remains blank until genuinely observed..

**P01-STORE-LIFETIME (limitation)** — Create3 in one supplied store then initialise a genuinely new store; Compare direct /notes/3 before/after new store lifetime. Expected contract: Fresh store seed has1/2, so new3 absent; no durable persistence claimed. Witness: Store instance identity and seed, not server refresh guarantee.

**P03-NESTED** — GET /notes/42; Accept:text/html. Expected contract: static-only:404; universal:index; narrow repaired policy:index HTML; actual browser boot separate.

**P03-ROOT** — GET /; Accept:text/html. Expected contract: Built document delivered; exact index body identity.

**P03-HEAD** — HEAD /notes/42; Accept:text/html. Expected contract: Eligible status/headers; empty response body; no inferred React boot.

**P03-ASSET** — GET /assets/app-a1b2c3.js; Accept:*/*. Expected contract: Existing static bytes/type/cache behavior; filename is fixed, not proof of content hash.

**P03-ICON** — GET /icon.svg; Accept:*/*. Expected contract: Actual icon bytes/type preserved.

**P03-API-MISS** — GET /api/missing; Accept:text/html. Expected contract: Completing supplied API router returns JSON404 even in universal broken mode.

**P03-API-ROOT** — GET /api; Accept:text/html. Expected contract: Exact API namespace remains outside HTML fallback.

**P03-API-KNOWN** — GET /api/status; Accept:application/json. Expected contract: Supplied API response/status/envelope preserved.

**P03-MISSING-ASSET** — GET /assets/missing.js; Accept:text/html. Expected contract: Universal broken mode source implies HTML200 index; narrow policy preserves non-HTML404.

**P03-FILE-LIKE** — GET /release.v2; Accept:text/html. Expected contract: Extension-like path excluded, no successful index fallback.

**P03-METHOD** — POST /notes/42; Accept:text/html. Expected contract: No index; stable non-navigation404 or declared policy response, never fabricated success.

**P03-ACCEPT** — GET /notes/42; Accept:application/json. Expected contract: No HTML fallback; record actual content negotiation outcome.

**P03-NAMESPACE** — GET /apiary; Accept:text/html. Expected contract: Outside exact/api namespace; canonical startsWith(/api) is documented defect; named private successor eligible navigation.

**P03-MISSING-INDEX** — GET /notes/42; Accept:text/html. Expected contract: Separate missing-index fixture only; sanitized pre-header500 forwarding, no path/stack leak. This does not witness a post-header stream failure..

**P03-POST-HEADER** — GET /notes/42; Accept:text/html. Expected contract: Use a separate callback/stream-error fixture. When headersSent is already true, forward the exact error to next(error) without attempting a fresh JSON500 or second send. Source/captured-callback model and actual Express streaming remain distinct, pending evidence classes..

**P03-LATER** — GET /notes/42; Accept:text/html. Expected contract: Prior rejection does not poison later eligible request.

**P03-UNKNOWN-CLIENT** — GET /unlisted-client-path; Accept:text/html. Expected contract: Narrow server supplies index; actual booted client decides catch-all UI.

## Economic Informatics transfer

Explain cause→observable consequence→economic implication→limitation using your own witness: URL record identity, unsaved revision draft, confirmed resource within its explicit scope and initial document delivery. Stale identity can misdirect an order/invoice review; HTML200 alone is no proof of a saved transaction, authorisation or durable database.

## Teaching rubric

Experiment and technical result: 3.0 points.

Reproducible evidence: 2.0 points.

Explanation of mechanism: 2.0 points.

Critical Gemini audit: 1.5 points.

Limitations and reflection: 1.0 points.

Completeness and format: 0.5 points.

Total 10.0. Separate atomic constructs; no automatic marks and no extra P02 full-completion criterion.

## Troubleshooting and source-only fallback

**The expected folders are absent.** Stop. Keep the ZIP. Locate the actual extracted root; if there is one wrapper, enter it. Do not rebuild the tree manually or overwrite an earlier folder.

**Node/npm/dependencies or an app command are unavailable.** Record the exact command/error and BLOCKED/NOT_EXECUTED. No installation is authorised by this guide route. Continue source-only reading and preserve a draft.

**An unavailable starter or a failing objective appears.** Name the exact assertion and source/test identity. Implement only the permitted file. Parser/timeout/crash/dependency failures remain distinct blocks; no error is automatically expected.

**The browser shows a different page or origin.** Use the exact printed local URL and the dedicated app tab. A file:// project index, remote tab or old localhost process is not this run.

**Progress or form browser storage fails.** Keep the visible error. Progress is reading-only. For form evidence export portable JSON. Do not assume a save succeeded; clearing does not erase exported copies.

**Copy is unavailable under file://.** Select the visible command/prompt text and use normal copy. The fallback selection is shown; no permission change or external clipboard service is needed.

**The saved PDF clips text or lacks a referenced figure.** Do not submit that file. Correct the form/DOCX, renew declaration, save a successor and inspect every page again. A filename placeholder does not insert an image.

**Moodle final status remains Draft or the activity is ambiguous.** STOP. Preserve the reviewed local PDF. Complete the actually available final-submit route or ask the teacher for the exact activity. Never invent a receipt or deadline.

**No bounded genuine Gemini exchange occurred.** Record PENDING and the actual block. Only a real prior teacher-approved alternative can be recorded; neither a package example nor a selector grants approval.

Read the exact source/contracts, write predictions and record SOURCE. Unrun app/test/HTTP/browser/Gemini/Moodle observations remain NOT_EXECUTED/PENDING. Source-only work does not replace required actual technical evidence or grant a teacher alternative.

## Glossary

**URL** — The address naming a public application state or resource; this does not prove a saved change.

**Route** — A rule connecting an application URL state to its rendered view.

**Path parameter** — The variable part of a path such as noteId in /notes/:noteId.

**Controlled form** — Inputs whose temporary values are owned explicitly by React state.

**Draft** — Unconfirmed editable values; a visible draft is not a confirmed saved resource.

**Push / replace** — Different history changes. The destination alone does not distinguish them.

**Missing note / unknown page** — A recognised route with absent note data differs from an unrecognised client path.

**SPA deep link** — A nested application URL loaded directly; the server must deliver the initial document before the client can route.

**Accept / Content-Type** — Accept describes requested representations; Content-Type describes the response body representation.

**Positive control** — A preserved case that should remain healthy while an affected case demonstrates a defect.

**Body identity** — Actual response bytes compared with the exact supplied fixture, not a familiar asset filename.

**Headers sent** — The response has begun; an error cannot safely start a second fresh response.

**Evidence class** — SOURCE, MODEL, REACT_TEST, HTTP_LOOPBACK, REAL_BROWSER or NOT_EXECUTED, recorded separately for each witness.

**PACKAGE_ID** — The package identity produced from its documented manifest method, not a version guessed from a filename.

**Field completeness** — A structural record check, not authentication, technical qualification, marking or Moodle submission.


## Later qualified check commands

**projects/p01/student** — npm run test:baseline; npm run test:objective; npm run test:regression; npm run build; npm run dev. Run each command separately after qualification. Preserve its actual output. A source hash or final URL alone is insufficient.

**portfolio/p03/student** — npm run test:baseline; npm run test:objective; npm run test:regression; npm start. Run each command separately. No build:client. Actual browser boot and streaming remain separate.

**Student package root** — node tools/S09_VERIFY_PROJECT_BOUNDARY_v1_2_0.mjs --check-source p01. Source statuses EXACT_STARTER_BYTES / ALLOWED_OBJECTIVE_EDIT_ONLY / PROTECTED_SOURCE_MISMATCH are not correctness.

**Student package root** — node tools/S09_VERIFY_PROJECT_BOUNDARY_v1_2_0.mjs --check-source p03. Protected P03 build/evidence/API/tests/lockfile remain exact. Allowed edit alone does not pass the repair.


## Source and documentation boundaries

Exact supplied U09 specs/starters and the current local Phase1 contract determine this route. Original README timing, full-solution prompts and historic validation text remain preserved sources, not current successful runs. No live documentation/browser UI was checked during production.

Optional official documentation, not required for this guide: React useEffect https://react.dev/reference/react/useEffect; Express error handling https://expressjs.com/en/guide/error-handling.html; Node fileURLToPath https://nodejs.org/api/url.html. Links do not qualify prescribed package pins.

Seven images are new precise locally authored illustrative diagrams, not real Windows/browser/Gemini/Moodle screenshots. Their source SVGs remain inspectable. Detailed creation/provenance records are retained in the private audit.

Local Moodle companions: moodle/MOODLE_UPLOAD_GUIDE_S09_EN_GB.md; moodle/COPY_PASTE_MOODLE_ASSIGNMENT_S09_EN_GB.txt; moodle/MOODLE_RUBRIC_S09_EN_GB.csv. Actual activity/rules/status remain institutional observations.
