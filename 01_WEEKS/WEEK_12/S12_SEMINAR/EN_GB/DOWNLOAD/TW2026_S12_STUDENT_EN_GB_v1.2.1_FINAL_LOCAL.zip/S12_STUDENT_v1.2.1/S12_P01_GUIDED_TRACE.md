# S12 required individual P01 trace

Use this source/model trace for E07. It is a supplied observation to analyse individually, not evidence that you ran HTTP, Express or a real WebSocket. Open `04_OFFLINE_FALLBACK/S12_P01_SUPPLIED_TRACE.json` as text. Select SOURCE_ANALYSIS when annotating the source/witness; select MODEL only if you actually reproduce a declared model. Retain the relevant locator, prediction, interpretation and limitation in your own form. Do not relabel supplied results as your execution.

## Before examining the result

Predict whether HTTP 202 means the calculation finished. Predict whether two principals with the same connection label share a recipient. Write both predictions before revealing the witness. The opaque request ID is a parcel label: the cashier accepting a parcel has not delivered it. For an economics report, exporting an acceptance notice as a completed total can produce a false report.

## Trace the five boundaries

| Boundary | Supplied locator | Individual action | What to record |
| --- | --- | --- | --- |
| Acceptance | T01; `app.js:15–20` and `reply-coordinator.js:48–60` | Locate `{requestId:"r1", status:"accepted"}` and the pending count before completion. | HTTP route is POST `/api/calculations`; the source maps acceptance to 202. No live request was sent by this trace. State why acceptance is not completion. |
| Registration | T02/T03; `reply-coordinator.js:1–2,26–30,48–54` | Compare synthetic-A/desk with synthetic-B/desk. Locate the refusal for unregistered synthetic-C. | Recipient key combines principal and connection label. Fixture identity is not production authentication. |
| Target and correlation | T02; `reply-coordinator.js:40–45` | Compare A and B frame arrays after result 5. | Only A receives the completed frame for r1. Match the opaque request ID with the caller; no broadcast. |
| Replacement and disconnect | T05–T07; `reply-coordinator.js:26–37` | Compare replacement close code 4401 with disconnect diagnostics. | Old socket cleanup leaves the new registration intact. Disconnect removes the socket entry but leaves pending work until completion. |
| Failure limit | T04; `reply-coordinator.js:51–52` | Follow two acceptances with the same opaque ID. | The original `pending.set` overwrites ownership: A's first result is sent to B and B's later result is dropped. This is a source defect, not healthy correlation. |

The locators refer to the unchanged original source identified by SHA-256 in the supplied JSON. The teacher's private source preserves the complete original. This public witness exposes its specific behaviour without asking you to implement P01.

## Individual evidence checklist

1. Record evidence class and T01/T02/T03 locators in the P01 acceptance, registration and delivery fields.
2. Explain T04 as a counterexample to “one pending Map guarantees correct ownership”. Do not silently repair or claim that the original rejects duplicate IDs.
3. Explain T05 and T06: local disconnect does not prove remote cancellation and pending memory can remain until work settles. The source has no deadline for work that never settles.
4. Distinguish proposed production policy (authenticated identity, lifetime-unique IDs, resource deadlines and explicit cancellation) from the observed original.
5. Record one limit: the supplied fake socket does not establish browser, network, authentication or production safety. The original HTTP Location header also does not prove a polling endpoint exists.

No P01 source edit is assessed. No Redis/BullMQ setup is required. Required evidence belongs in the same `TW2026_S12_CODE.pdf` as P03. If this supplied trace cannot be read, record the actual block and keep a draft; ask the teacher to resolve access before normal completion.

## Optional real protocol lane

An actual HTTP/WebSocket observation needs the separately prepared environment and explicit qualification. On the intended local application tab, the address must show `127.0.0.1`; Network on `chatgpt.com` is the wrong tab. Only claim REAL_PROTOCOL for a run you actually observed. Redact credentials, cookies, raw connection URLs and personal data. This phase starts no server and produces no real protocol receipt.
