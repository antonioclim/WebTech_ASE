# Week 03 public WIP preview

Wrapper version 1.2.0; original C03/S03 student objects remain version 1.1.0. This new wrapper is prepared for owner-controlled publication as an explicitly unqualified preview. It is not a qualified release and does not claim that publication has already occurred.

The two original object trees and the ZIPs in DOWNLOAD are byte-identical to their source distributions. Their historical build-time hold statements remain unchanged. This new wrapper changes distribution labelling only; it does not record runtime, browser, platform or application gates as passed.

Open index.html after extracting the complete archive. COURSE and SEMINAR are ready to browse locally. Do not extract the duplicate ZIPs in DOWNLOAD just to view the materials. Their role is to preserve the exact original distributions.

P01 Dataset Transformer is the central implementation. P03 Generated-Code Audit is required after the meeting. P02 Rule Engine is optional.

One final PDF: TW2026_S03_GROUP_Surname_GivenName.pdf. There is no separate course Assignment. Dates and live Moodle configuration are set separately by the teacher.

Known pending qualification categories: reference_runtime, real_browser, native_platform_acceptance. Runtime commands inside the teaching materials are for the learning activity after prerequisites are satisfied, not for publishing this repository. Do not install anything merely to inspect the HTML. A package identity proves file consistency, not correctness or truthful execution.

Never upload teacher archives, solutions, credentials or student work. No GitHub Actions, Pages or Release publication is required for this download-only preview.
